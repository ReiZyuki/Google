import React, { useState } from 'react';
import { Terminal, Globe, Square, X, Zap } from 'lucide-react';

interface FloatingBallOverlayProps {
  isServerRunning: boolean;
  onNavigateTab: (tab: 'terminal' | 'webview') => void;
  onStopServer: () => void;
  onDismiss: () => void;
}

export const FloatingBallOverlay: React.FC<FloatingBallOverlayProps> = ({
  isServerRunning,
  onNavigateTab,
  onStopServer,
  onDismiss,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [position, setPosition] = useState({ x: 20, y: 120 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    setDragStart({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    });
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setPosition({
      x: Math.max(10, Math.min(300, e.clientX - dragStart.x)),
      y: Math.max(50, Math.min(500, e.clientY - dragStart.y)),
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isDragging) {
      setIsDragging(false);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch (err) {
        // pointer capture released
      }
    }
  };

  return (
    <div
      className="absolute z-40 select-none touch-none"
      style={{
        right: `${position.x}px`,
        top: `${position.y}px`,
      }}
    >
      {/* Expanded Quick Action Menu */}
      {isOpen && (
        <div className="absolute right-0 bottom-14 bg-[#181524] border border-[#2F2945] rounded-2xl shadow-2xl p-2.5 flex flex-col gap-1.5 w-44 backdrop-blur-md animate-in fade-in zoom-in-95">
          <div className="text-[10px] uppercase font-bold tracking-wider text-[#A89EBF] px-2 py-1 flex items-center justify-between border-b border-[#2F2945]">
            <span>Runner Ball</span>
            {isServerRunning && (
              <span className="flex items-center gap-1 text-[#34D399] font-mono text-[9px]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#34D399] animate-pulse" />
                ACTIVE
              </span>
            )}
          </div>

          <button
            onClick={() => {
              onNavigateTab('terminal');
              setIsOpen(false);
            }}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-[#221E33] text-xs text-[#F3EFFC] transition"
          >
            <Terminal className="w-3.5 h-3.5 text-[#B347FF]" />
            <span>Terminal</span>
          </button>

          <button
            onClick={() => {
              onNavigateTab('webview');
              setIsOpen(false);
            }}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-[#221E33] text-xs text-[#F3EFFC] transition"
          >
            <Globe className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>WebView</span>
          </button>

          {isServerRunning && (
            <button
              onClick={() => {
                onStopServer();
                setIsOpen(false);
              }}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-[#EF4444]/20 text-xs text-[#EF4444] transition"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>Stop Server</span>
            </button>
          )}

          <button
            onClick={() => {
              onDismiss();
              setIsOpen(false);
            }}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-[#221E33] text-xs text-[#A89EBF] hover:text-white transition border-t border-[#2F2945]"
          >
            <X className="w-3.5 h-3.5" />
            <span>Hide Ball</span>
          </button>
        </div>
      )}

      {/* The Floating Ball */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onClick={(e) => {
          if (!isDragging) {
            setIsOpen(!isOpen);
          }
        }}
        className={`w-12 h-12 rounded-full flex items-center justify-center cursor-pointer shadow-xl transition-transform active:scale-95 border ${
          isOpen
            ? 'bg-[#B347FF] border-white text-white ring-4 ring-[#9205F2]/40'
            : 'bg-[#9205F2] border-[#C084FC] text-white hover:brightness-110'
        }`}
        title="Runner Floating Ball"
      >
        <Zap className="w-5 h-5 fill-current" />

        {/* Server Active Indicator Dot */}
        {isServerRunning && (
          <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-[#10B981] border-2 border-[#181524] animate-pulse" />
        )}
      </div>
    </div>
  );
};
