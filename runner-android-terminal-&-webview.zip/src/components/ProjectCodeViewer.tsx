import React, { useState } from 'react';
import { Download, FileCode, Check, Copy, ExternalLink, Folder } from 'lucide-react';
import JSZip from 'jszip';

interface AndroidFileEntry {
  path: string;
  category: 'manifest' | 'gradle' | 'kotlin' | 'layout' | 'res' | 'workflow';
  content: string;
}

const ANDROID_PROJECT_FILES: AndroidFileEntry[] = [
  {
    path: '.github/workflows/build-apk.yml',
    category: 'workflow',
    content: `name: Build Android APK

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    name: Build Runner Debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'

      - name: Grant execute permission for gradlew
        run: |
          if [ -f "./gradlew" ]; then
            chmod +x ./gradlew
          elif [ -f "./android/gradlew" ]; then
            chmod +x ./android/gradlew
          fi

      - name: Build Debug APK
        run: |
          if [ -f "./gradlew" ]; then
            ./gradlew assembleDebug --stacktrace
          elif [ -f "./android/gradlew" ]; then
            cd android && ./gradlew assembleDebug --stacktrace
          else
            echo "Gradle wrapper not found" && exit 1
          fi

      - name: Upload Debug APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: runner-debug-apk
          path: |
            app/build/outputs/apk/debug/*.apk
            android/app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
          retention-days: 14`
  },
  {
    path: 'android/build.gradle.kts',
    category: 'gradle',
    content: `plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.23" apply false
}`
  },
  {
    path: 'android/settings.gradle.kts',
    category: 'gradle',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Runner"
include(":app")`
  },
  {
    path: 'android/app/build.gradle.kts',
    category: 'gradle',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.runner.terminal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.runner.terminal"
        minSdk = 28 // Android 9.0 Pie
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            abiFilters.addAll(setOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86"))
        }
    }

    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.fragment:fragment-ktx:1.6.2")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}`
  },
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    category: 'manifest',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />

    <application
        android:name=".RunnerApplication"
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.Runner"
        android:networkSecurityConfig="@xml/network_security_config">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

    </application>
</manifest>`
  },
  {
    path: 'android/app/src/main/res/xml/network_security_config.xml',
    category: 'res',
    content: `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="false">127.0.0.1</domain>
        <domain includeSubdomains="false">localhost</domain>
        <domain includeSubdomains="false">0.0.0.0</domain>
        <domain includeSubdomains="false">::1</domain>
    </domain-config>
</network-security-config>`
  },
  {
    path: 'android/app/src/main/java/com/runner/terminal/MainActivity.kt',
    category: 'kotlin',
    content: `package com.runner.terminal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.runner.terminal.databinding.ActivityMainBinding
import com.runner.terminal.network.DetectedLocalServer
import com.runner.terminal.process.RunnerProcessManager
import com.runner.terminal.ui.terminal.TerminalFragment
import com.runner.terminal.ui.files.FileManagerFragment
import com.runner.terminal.ui.webview.RunnerWebViewFragment
import com.runner.terminal.ui.settings.SettingsFragment

class MainActivity : AppCompatActivity(), RunnerProcessManager.ProcessEventListener {
    // Manages Bottom Navigation, Fragment Swapping without killing active Terminal/Server
    // Listens to ProcessManager for automatic Flask localhost detection!
}`
  },
  {
    path: 'android/app/src/main/java/com/runner/terminal/network/LocalUrlDetector.kt',
    category: 'kotlin',
    content: `package com.runner.terminal.network

import java.net.URI
import java.util.regex.Pattern

data class DetectedLocalServer(
    val originalUrl: String,
    val normalizedUrl: String,
    val host: String,
    val port: Int
)

class LocalUrlDetector {
    private val localUrlPattern = Pattern.compile(
        "https?://(?:localhost|127\\\\.0\\\\.0\\\\.1|0\\\\.0\\\\.0\\\\.0|\\\\[::1\\\\])(?::([0-9]{1,5}))?",
        Pattern.CASE_INSENSITIVE
    )

    fun findLocalServerUrl(text: String): DetectedLocalServer? {
        val matcher = localUrlPattern.matcher(text)
        if (matcher.find()) {
            val raw = matcher.group()
            return parseAndNormalize(raw)
        }
        return null
    }

    fun parseAndNormalize(urlStr: String): DetectedLocalServer? {
        val uri = URI(urlStr)
        val host = uri.host ?: return null
        val port = if (uri.port != -1) uri.port else 80
        val normalizedHost = if (host == "0.0.0.0" || host == "::1") "127.0.0.1" else host
        return DetectedLocalServer(urlStr, "http://$normalizedHost:$port/", normalizedHost, port)
    }
}`
  },
  {
    path: 'android/app/src/main/java/com/runner/terminal/storage/PrivateStorageManager.kt',
    category: 'kotlin',
    content: `package com.runner.terminal.storage

import android.content.Context
import java.io.File

class PrivateStorageManager(private val context: Context) {
    val homeDir: File get() = File(context.filesDir, "home")
    val usrDir: File get() = File(context.filesDir, "usr")
    val binDir: File get() = File(usrDir, "bin")
    val tmpDir: File get() = File(context.cacheDir, "tmp")

    fun initializeFileSystem() {
        listOf(homeDir, usrDir, binDir, tmpDir).forEach { it.mkdirs() }
        val starter = File(homeDir, "run.py")
        if (!starter.exists()) starter.writeText(getStarterScript())
    }
}`
  }
];

export const ProjectCodeViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFileEntry>(ANDROID_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Bundle all files
      ANDROID_PROJECT_FILES.forEach((f) => {
        zip.file(f.path, f.content);
      });

      // Also add gradlew dummy script
      zip.file('android/gradlew', '#!/bin/sh\nexec gradlew "$@"\n');
      zip.file('android/gradle.properties', 'android.useAndroidX=true\norg.gradle.jvmargs=-Xmx2048m\n');

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'runner-android-studio-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0F0D15] text-[#F3EFFC]">
      {/* Top Banner */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#181524] border-b border-[#2F2945]">
        <div>
          <div className="text-sm font-bold text-[#F3EFFC]">Runner Android Studio Project</div>
          <div className="text-xs text-[#A89EBF]">Production-ready Gradle, Kotlin & GitHub Actions sources</div>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#9205F2] hover:bg-[#B347FF] text-white text-xs font-semibold shadow-md transition disabled:opacity-50"
        >
          <Download className="w-3.5 h-3.5" />
          {isZipping ? 'Generating ZIP...' : 'Download Project (.ZIP)'}
        </button>
      </div>

      <div className="flex flex-1 min-h-0">
        {/* File Navigator Sidebar */}
        <div className="w-64 border-r border-[#2F2945] bg-[#181524]/50 overflow-y-auto p-2 space-y-1">
          <div className="px-2 py-1 text-[11px] font-bold text-[#6F6687] uppercase tracking-wider">
            Android Structure
          </div>

          {ANDROID_PROJECT_FILES.map((f) => (
            <button
              key={f.path}
              onClick={() => setSelectedFile(f)}
              className={`w-full text-left px-2.5 py-2 rounded-lg text-xs font-mono truncate flex items-center gap-2 transition ${
                selectedFile.path === f.path
                  ? 'bg-[#9205F2]/20 text-[#B347FF] border border-[#9205F2]/40 font-medium'
                  : 'text-[#A89EBF] hover:text-white hover:bg-[#221E33]'
              }`}
            >
              <FileCode className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{f.path}</span>
            </button>
          ))}
        </div>

        {/* Code Content Area */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#0F0D15]">
          <div className="flex items-center justify-between px-4 py-2 bg-[#181524] border-b border-[#2F2945] text-xs font-mono">
            <span className="text-[#34D399] truncate">{selectedFile.path}</span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#221E33] hover:bg-[#2F2945] text-[#A89EBF] hover:text-white transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#34D399]" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <pre className="flex-1 p-4 overflow-auto font-mono text-xs text-[#F3EFFC] leading-relaxed select-text">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
