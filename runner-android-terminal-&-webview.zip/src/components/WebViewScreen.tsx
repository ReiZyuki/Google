import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, RotateCw, X, Terminal, ExternalLink, ShieldCheck, AlertCircle } from 'lucide-react';
import { DetectedServer } from '../types/runner';

interface WebViewScreenProps {
  server: DetectedServer | null;
  isRunning: boolean;
  onReturnToTerminal: () => void;
  onClose: () => void;
}

export const WebViewScreen: React.FC<WebViewScreenProps> = ({
  server,
  isRunning,
  onReturnToTerminal,
  onClose,
}) => {
  const [requestCount, setRequestCount] = useState(1);
  const [isReloading, setIsReloading] = useState(false);
  const [activeTab, setActiveTab] = useState<'home' | 'api' | 'metrics'>('home');

  const handleReload = () => {
    setIsReloading(true);
    setTimeout(() => {
      setIsReloading(false);
      setRequestCount((prev) => prev + 1);
    }, 400);
  };

  const url = server?.normalizedUrl || 'http://127.0.0.1:5000';

  return (
    <div className="flex flex-col h-full bg-[#0F0D15] text-[#F3EFFC]">
      {/* Top Browser Navigation Bar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#181524] border-b border-[#2F2945]">
        <div className="flex items-center gap-1">
          <button
            onClick={() => {}}
            className="p-1.5 rounded-lg text-[#6F6687] hover:text-[#F3EFFC] hover:bg-[#221E33] transition"
            title="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => {}}
            className="p-1.5 rounded-lg text-[#6F6687] hover:text-[#F3EFFC] hover:bg-[#221E33] transition"
            title="Forward"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={handleReload}
            className={`p-1.5 rounded-lg text-[#A89EBF] hover:text-[#F3EFFC] hover:bg-[#221E33] transition ${
              isReloading ? 'animate-spin' : ''
            }`}
            title="Reload"
          >
            <RotateCw className="w-4 h-4" />
          </button>
        </div>

        {/* Address Bar */}
        <div className="flex-1 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0F0D15] border border-[#2F2945] text-xs font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-[#34D399]" />
          <span className="text-[#34D399] font-medium truncate">{url}</span>
          <span className="ml-auto text-[10px] text-[#A89EBF] uppercase px-1.5 py-0.5 rounded bg-[#221E33]">
            Loopback
          </span>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onReturnToTerminal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#9205F2]/20 border border-[#9205F2]/40 text-[#B347FF] hover:bg-[#9205F2]/30 text-xs font-medium transition"
            title="Return to active Terminal session without terminating server"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Terminal</span>
          </button>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#F87171] hover:bg-[#F87171]/20 transition"
            title="Close WebView"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Embedded WebView Canvas */}
      <div className="flex-1 relative overflow-y-auto">
        {!isRunning ? (
          /* Clean Offline / Disconnected State */
          <div className="flex flex-col items-center justify-center h-full p-8 text-center animate-fade-in">
            <div className="w-16 h-16 rounded-2xl bg-[#F87171]/10 border border-[#F87171]/30 flex items-center justify-center text-[#F87171] mb-4">
              <AlertCircle className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-bold text-[#F3EFFC]">Local Server Stopped</h2>
            <p className="max-w-sm text-sm text-[#A89EBF] mt-2">
              The Flask process at <code className="text-[#B347FF]">{url}</code> is no longer active.
              Return to the terminal and execute <code className="text-[#34D399]">python run.py</code> to restart it.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                onClick={onReturnToTerminal}
                className="px-5 py-2 rounded-xl bg-[#9205F2] hover:bg-[#B347FF] text-white text-sm font-semibold transition shadow-md"
              >
                Back to Terminal
              </button>
            </div>
          </div>
        ) : (
          /* Live Rendered Flask Web Application inside Runner */
          <div className="p-6 max-w-lg mx-auto my-6">
            <div className="bg-[#181524] border border-[#2F2945] rounded-2xl p-6 shadow-xl text-center">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#9205F2]/20 border border-[#9205F2] text-[#B347FF] text-xs font-semibold mb-4">
                <span className="w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
                Runner Integrated WebView Active
              </div>

              <h1 className="text-2xl font-bold text-[#F3EFFC]">Flask Server Online!</h1>
              <p className="text-sm text-[#A89EBF] mt-2 leading-relaxed">
                Runner detected the local HTTP URL from terminal output and opened it directly in the
                built-in WebView. You can switch back and forth without losing state.
              </p>

              {/* Sub navigation within the web application */}
              <div className="flex items-center justify-center gap-2 mt-6 p-1 bg-[#0F0D15] rounded-xl border border-[#2F2945]">
                <button
                  onClick={() => setActiveTab('home')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    activeTab === 'home' ? 'bg-[#9205F2] text-white' : 'text-[#A89EBF]'
                  }`}
                >
                  Overview
                </button>
                <button
                  onClick={() => setActiveTab('api')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    activeTab === 'api' ? 'bg-[#9205F2] text-white' : 'text-[#A89EBF]'
                  }`}
                >
                  API Status
                </button>
                <button
                  onClick={() => setActiveTab('metrics')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    activeTab === 'metrics' ? 'bg-[#9205F2] text-white' : 'text-[#A89EBF]'
                  }`}
                >
                  Process Info
                </button>
              </div>

              <div className="my-6 p-4 rounded-xl bg-[#0F0D15] border border-[#2F2945] text-left">
                {activeTab === 'home' && (
                  <div>
                    <div className="text-[11px] font-mono text-[#6F6687] uppercase tracking-wider">
                      Interactive Client-Server Loop
                    </div>
                    <div className="text-lg font-bold text-[#34D399] font-mono mt-1">
                      PORT 5000 • 200 OK
                    </div>
                    <div className="text-xs text-[#A89EBF] mt-2">
                      Handled requests:{' '}
                      <strong className="text-[#F3EFFC]">{requestCount}</strong>
                    </div>
                  </div>
                )}

                {activeTab === 'api' && (
                  <div className="font-mono text-xs text-[#A89EBF] space-y-1">
                    <div className="text-[#34D399]">GET /api/status HTTP/1.1</div>
                    <div>Host: 127.0.0.1:5000</div>
                    <div>X-Runner-Version: 1.0.0</div>
                    <div className="text-[#B347FF] mt-2">{'{"status": "running", "engine": "python3"}'}</div>
                  </div>
                )}

                {activeTab === 'metrics' && (
                  <div className="text-xs text-[#A89EBF] space-y-1.5 font-mono">
                    <div className="flex justify-between">
                      <span>Server Engine:</span>
                      <span className="text-[#F3EFFC]">Python 3.11</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Address:</span>
                      <span className="text-[#34D399]">127.0.0.1:5000</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sandbox:</span>
                      <span className="text-[#B347FF]">Runner Private Storage</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => setRequestCount((prev) => prev + 1)}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#9205F2] hover:bg-[#B347FF] text-white font-semibold text-sm transition shadow-md"
                >
                  Send Interactive Test Request
                </button>
                <button
                  onClick={onReturnToTerminal}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-[#221E33] hover:bg-[#2F2945] text-[#F3EFFC] text-sm font-medium transition border border-[#2F2945]"
                >
                  Return to Terminal
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
