import React from 'react';
import { Moon, Sun, Monitor, Terminal, Zap, Shield, Clock, CircleDot } from 'lucide-react';
import { AppSettings } from '../types/runner';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
}) => {
  return (
    <div className="flex flex-col h-full bg-[#0F0D15] text-[#F3EFFC] p-4 overflow-y-auto space-y-4">
      <div>
        <h2 className="text-xl font-bold text-[#F3EFFC]">Settings</h2>
        <p className="text-xs text-[#A89EBF] mt-1">
          Configure theme, terminal emulator, floating ball, and localhost detection engine
        </p>
      </div>

      {/* Theme Card */}
      <div className="p-4 rounded-2xl bg-[#181524] border border-[#2F2945] space-y-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#F3EFFC]">
          <Moon className="w-4 h-4 text-[#B347FF]" />
          Theme Appearance
        </div>

        <div className="grid grid-cols-3 gap-2 text-xs">
          <button
            onClick={() => onUpdateSettings({ theme: 'dark' })}
            className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition ${
              settings.theme === 'dark'
                ? 'bg-[#9205F2]/20 border-[#9205F2] text-[#F3EFFC]'
                : 'bg-[#0F0D15] border-[#2F2945] text-[#A89EBF] hover:text-white'
            }`}
          >
            <Moon className="w-5 h-5 text-[#B347FF]" />
            <span>Dark (#9205f2)</span>
          </button>

          <button
            onClick={() => onUpdateSettings({ theme: 'light' })}
            className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition ${
              settings.theme === 'light'
                ? 'bg-[#9205F2]/20 border-[#9205F2] text-[#F3EFFC]'
                : 'bg-[#0F0D15] border-[#2F2945] text-[#A89EBF] hover:text-white'
            }`}
          >
            <Sun className="w-5 h-5 text-[#FBBF24]" />
            <span>Light</span>
          </button>

          <button
            onClick={() => onUpdateSettings({ theme: 'system' })}
            className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition ${
              settings.theme === 'system'
                ? 'bg-[#9205F2]/20 border-[#9205F2] text-[#F3EFFC]'
                : 'bg-[#0F0D15] border-[#2F2945] text-[#A89EBF] hover:text-white'
            }`}
          >
            <Monitor className="w-5 h-5 text-[#38BDF8]" />
            <span>System</span>
          </button>
        </div>
      </div>

      {/* Floating Ball Overlay */}
      <div className="p-4 rounded-2xl bg-[#181524] border border-[#2F2945] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#F3EFFC]">
            <CircleDot className="w-4 h-4 text-[#B347FF]" />
            Floating Ball Overlay
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.floatingBallEnabled}
              onChange={(e) => onUpdateSettings({ floatingBallEnabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-[#221E33] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#9205F2]"></div>
          </label>
        </div>
        <p className="text-xs text-[#A89EBF] leading-relaxed">
          Draggable floating quick action ball allowing you to switch between Terminal, WebView, and stop active servers with a single tap.
        </p>
      </div>

      {/* Flask Auto-detection & WebView */}
      <div className="p-4 rounded-2xl bg-[#181524] border border-[#2F2945] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#F3EFFC]">
            <Zap className="w-4 h-4 text-[#34D399]" />
            Auto-Open Localhost WebView
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.autoOpenWebView}
              onChange={(e) => onUpdateSettings({ autoOpenWebView: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-[#221E33] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#9205F2]"></div>
          </label>
        </div>
        <p className="text-xs text-[#A89EBF] leading-relaxed">
          When a command outputs a localhost or 127.0.0.1 HTTP URL, Runner verifies socket readiness and automatically opens the built-in WebView without opening external browsers.
        </p>

        {/* Timeout Slider */}
        <div className="pt-2 border-t border-[#2F2945]/60">
          <div className="flex items-center justify-between text-xs text-[#A89EBF]">
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#B347FF]" />
              Readiness Timeout:
            </span>
            <span className="font-mono text-[#F3EFFC] font-semibold">
              {settings.serverTimeoutSeconds}s
            </span>
          </div>
          <input
            type="range"
            min="2"
            max="15"
            value={settings.serverTimeoutSeconds}
            onChange={(e) => onUpdateSettings({ serverTimeoutSeconds: Number(e.target.value) })}
            className="w-full mt-2 accent-[#9205F2]"
          />
        </div>
      </div>

      {/* Terminal Configuration */}
      <div className="p-4 rounded-2xl bg-[#181524] border border-[#2F2945] space-y-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#F3EFFC]">
          <Terminal className="w-4 h-4 text-[#38BDF8]" />
          Terminal Font Size
        </div>

        <div className="flex items-center justify-between text-xs text-[#A89EBF]">
          <span>Current Size:</span>
          <span className="font-mono text-[#F3EFFC] font-semibold">
            {settings.terminalFontSize}px
          </span>
        </div>
        <input
          type="range"
          min="11"
          max="18"
          value={settings.terminalFontSize}
          onChange={(e) => onUpdateSettings({ terminalFontSize: Number(e.target.value) })}
          className="w-full accent-[#9205F2]"
        />
      </div>

      {/* Private Storage Paths Display */}
      <div className="p-4 rounded-2xl bg-[#181524] border border-[#2F2945] space-y-2">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#F3EFFC]">
          <Shield className="w-4 h-4 text-[#9205F2]" />
          App Private Storage Sandbox
        </div>
        <div className="p-3 rounded-xl bg-[#0F0D15] border border-[#2F2945] font-mono text-[11px] text-[#A89EBF] space-y-1">
          <div>HOME: /data/user/0/com.runner.terminal/files/home</div>
          <div>PREFIX: /data/user/0/com.runner.terminal/files/usr</div>
          <div>TMP: /data/user/0/com.runner.terminal/cache/tmp</div>
          <div>DOWNLOAD: /sdcard/Download</div>
        </div>
      </div>
    </div>
  );
};
