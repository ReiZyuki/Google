import React, { useState, useRef, useEffect } from 'react';
import { Play, Square, Trash2, Globe, Terminal as TermIcon, CornerDownLeft, Sparkles } from 'lucide-react';
import { DetectedServer, AppSettings } from '../types/runner';

interface TerminalViewProps {
  activeServer: DetectedServer | null;
  isRunning: boolean;
  onStartServer: () => void;
  onStopServer: () => void;
  onOpenWebView: (url: string) => void;
  settings: AppSettings;
}

export const TerminalView: React.FC<TerminalViewProps> = ({
  activeServer,
  isRunning,
  onStartServer,
  onStopServer,
  onOpenWebView,
  settings,
}) => {
  const [outputLines, setOutputLines] = useState<string[]>([
    'Runner Linux Environment [Version 1.0.0]',
    'Private Home: /data/user/0/com.runner.terminal/files/home',
    "Type 'help' for built-in tools or run Python/Flask servers directly.",
    '',
  ]);
  const [currentInput, setCurrentInput] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [currentDir, setCurrentDir] = useState('~');

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [outputLines]);

  const handleCommand = (cmd: string) => {
    const trimmed = cmd.trim();
    if (!trimmed) {
      setOutputLines((prev) => [...prev, `runner@localhost:${currentDir} $ `]);
      return;
    }

    setCommandHistory((prev) => [...prev, trimmed]);
    setHistoryIndex(-1);

    const promptLine = `runner@localhost:${currentDir} $ ${trimmed}`;
    const newLines = [...outputLines, promptLine];

    if (trimmed === 'clear') {
      setOutputLines([]);
      return;
    }

    if (trimmed === 'help') {
      setOutputLines([
        ...newLines,
        'Runner Shell & Runtime Helper:',
        '  • ls -la          : List files in current directory',
        '  • python run.py   : Launch Flask local server with auto-detection',
        '  • cat <filename>  : View file contents',
        '  • pwd             : Print working directory',
        '  • cd <dir>        : Change directory',
        '  • env             : Display private storage environment variables',
        '  • clear           : Clear terminal screen',
        '  • Stop (Ctrl+C)   : Terminate active server process',
        '',
      ]);
      return;
    }

    if (trimmed === 'pwd') {
      setOutputLines([
        ...newLines,
        currentDir === '~'
          ? '/data/user/0/com.runner.terminal/files/home'
          : `/data/user/0/com.runner.terminal/files/home/${currentDir}`,
        '',
      ]);
      return;
    }

    if (trimmed === 'env') {
      setOutputLines([
        ...newLines,
        'HOME=/data/user/0/com.runner.terminal/files/home',
        'PREFIX=/data/user/0/com.runner.terminal/files/usr',
        'PATH=/data/user/0/com.runner.terminal/files/usr/bin:/system/bin',
        'TMPDIR=/data/user/0/com.runner.terminal/cache/tmp',
        'PYTHONUNBUFFERED=1',
        'TERM=xterm-256color',
        '',
      ]);
      return;
    }

    if (trimmed.startsWith('ls')) {
      setOutputLines([
        ...newLines,
        '-rw-r--r-- 1 runner runner 1840 Sep 04 01:00 run.py',
        '-rw-r--r-- 1 runner runner  240 Sep 04 00:30 .bashrc',
        '-rw-r--r-- 1 runner runner  420 Sep 04 00:15 README.txt',
        'drwxr-xr-x 2 runner runner 4096 Sep 04 00:00 templates',
        '',
      ]);
      return;
    }

    if (trimmed.startsWith('cat ')) {
      const filename = trimmed.substring(4).trim();
      if (filename === 'run.py') {
        setOutputLines([
          ...newLines,
          '# Runner Sample Local Server',
          'from http.server import HTTPServer, BaseHTTPRequestHandler',
          'PORT = 5000',
          'HOST = "127.0.0.1"',
          'print(" * Running on http://127.0.0.1:5000 (Press CTRL+C to quit)")',
          '# ... (use File Manager to edit full code)',
          '',
        ]);
      } else if (filename === 'README.txt') {
        setOutputLines([
          ...newLines,
          'Welcome to Runner!',
          'A Termux-style terminal application with built-in WebView and automatic localhost URL detection.',
          '',
        ]);
      } else {
        setOutputLines([...newLines, `cat: ${filename}: No such file or directory`, '']);
      }
      return;
    }

    if (trimmed.startsWith('cd')) {
      const target = trimmed.substring(2).trim();
      if (!target || target === '~') {
        setCurrentDir('~');
      } else {
        setCurrentDir(target);
      }
      setOutputLines([...newLines, '']);
      return;
    }

    if (trimmed === 'python run.py' || trimmed === 'python3 run.py' || trimmed === 'flask run') {
      if (isRunning) {
        setOutputLines([
          ...newLines,
          '[Runner] Another process is already running (PID: 2841). Terminate it first.',
          '',
        ]);
        return;
      }

      setOutputLines([
        ...newLines,
        ' * Serving Runner Python Application',
        ' * Environment: production',
        ' * Runner Private Storage: /data/user/0/com.runner.terminal/files/home',
        ' * Running on http://127.0.0.1:5000 (Press CTRL+C to quit)',
        '[Runner Detector] Found localhost URL: http://127.0.0.1:5000',
        '[Runner] Verifying server socket readiness on port 5000...',
      ]);

      onStartServer();

      setTimeout(() => {
        setOutputLines((prev) => [
          ...prev,
          '[Runner] Socket connected! Server is reachable at http://127.0.0.1:5000',
          settings.autoOpenWebView
            ? '[Runner] Auto-opening built-in WebView...'
            : '[Runner] Server online. Tap "Open WebView" to inspect.',
          '',
        ]);

        if (settings.autoOpenWebView) {
          onOpenWebView('http://127.0.0.1:5000');
        }
      }, 900);
      return;
    }

    // Generic shell command output
    setOutputLines([
      ...newLines,
      `[Runner Shell] Executing command: ${trimmed}`,
      `Done. (exit code: 0)`,
      '',
    ]);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleCommand(currentInput);
      setCurrentInput('');
    } else if (e.key === 'ArrowUp') {
      if (commandHistory.length > 0) {
        const nextIndex = historyIndex === -1 ? commandHistory.length - 1 : Math.max(0, historyIndex - 1);
        setHistoryIndex(nextIndex);
        setCurrentInput(commandHistory[nextIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      if (historyIndex !== -1) {
        const nextIndex = historyIndex + 1;
        if (nextIndex >= commandHistory.length) {
          setHistoryIndex(-1);
          setCurrentInput('');
        } else {
          setHistoryIndex(nextIndex);
          setCurrentInput(commandHistory[nextIndex]);
        }
      }
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0F0D15] text-[#F3EFFC] font-mono select-text">
      {/* Active Server Detection Banner */}
      {activeServer && isRunning && (
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#181524] border-b border-[#2F2945] animate-fade-in">
          <div className="flex items-center gap-2.5 text-xs">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#34D399] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#34D399]"></span>
            </span>
            <span className="text-[#A89EBF]">
              Server Detected:{' '}
              <strong className="text-[#34D399] font-mono">{activeServer.normalizedUrl}</strong>
            </span>
          </div>

          <button
            onClick={() => onOpenWebView(activeServer.normalizedUrl)}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-sans font-semibold rounded-full bg-[#9205F2] hover:bg-[#B347FF] text-white transition shadow-sm"
          >
            <Globe className="w-3.5 h-3.5" />
            Open in WebView
          </button>
        </div>
      )}

      {/* Terminal Output Area */}
      <div
        className="flex-1 overflow-y-auto p-4 space-y-1"
        style={{ fontSize: `${settings.terminalFontSize}px` }}
        onClick={() => inputRef.current?.focus()}
      >
        {outputLines.map((line, idx) => (
          <div
            key={idx}
            className={`${
              line.startsWith('runner@localhost')
                ? 'text-[#B347FF] font-semibold'
                : line.includes('[Runner Detector]') || line.includes('Running on')
                ? 'text-[#34D399]'
                : line.includes('Warning') || line.includes('Error')
                ? 'text-[#F87171]'
                : 'text-[#F3EFFC]'
            } whitespace-pre-wrap leading-relaxed`}
          >
            {line}
          </div>
        ))}

        {/* Active prompt row */}
        <div className="flex items-center gap-2 pt-1 text-[#B347FF]">
          <span className="font-bold whitespace-nowrap">
            runner@localhost:{currentDir} ${' '}
          </span>
          <input
            ref={inputRef}
            type="text"
            value={currentInput}
            onChange={(e) => setCurrentInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent border-none outline-none text-[#F3EFFC] font-mono caret-[#9205F2] text-sm"
            placeholder="Type command..."
            autoFocus
          />
        </div>
        <div ref={bottomRef} />
      </div>

      {/* Quick Action Keys Bar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#181524] border-t border-[#2F2945] overflow-x-auto text-xs font-sans">
        {isRunning ? (
          <button
            onClick={onStopServer}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F87171]/20 border border-[#F87171]/40 text-[#F87171] hover:bg-[#F87171]/30 transition"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            Stop (Ctrl+C)
          </button>
        ) : (
          <button
            onClick={() => handleCommand('python run.py')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#9205F2]/20 border border-[#9205F2]/50 text-[#B347FF] hover:bg-[#9205F2]/30 transition font-mono font-medium"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            python run.py
          </button>
        )}

        <button
          onClick={() => handleCommand('ls -la')}
          className="px-2.5 py-1.5 rounded-lg bg-[#221E33] text-[#A89EBF] hover:text-white transition font-mono"
        >
          ls -la
        </button>

        <button
          onClick={() => handleCommand('help')}
          className="px-2.5 py-1.5 rounded-lg bg-[#221E33] text-[#A89EBF] hover:text-white transition"
        >
          help
        </button>

        <button
          onClick={() => handleCommand('clear')}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#221E33] text-[#A89EBF] hover:text-white transition"
        >
          <Trash2 className="w-3 h-3" />
          clear
        </button>

        <button
          onClick={() => handleCommand('env')}
          className="px-2.5 py-1.5 rounded-lg bg-[#221E33] text-[#A89EBF] hover:text-white transition"
        >
          env
        </button>
      </div>
    </div>
  );
};
