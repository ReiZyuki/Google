import React, { useState } from 'react';
import {
  Folder,
  FileCode,
  FileText,
  File,
  ArrowUp,
  Plus,
  RefreshCw,
  MoreVertical,
  Edit,
  Trash2,
  Info,
  Shield,
  DownloadCloud,
  X,
  Save,
  Play,
  Zap,
} from 'lucide-react';
import { VirtualFile } from '../types/runner';

interface FileManagerViewProps {
  files: VirtualFile[];
  onUpdateFile: (path: string, content: string) => void;
  onCreateFile: (name: string, isDir: boolean, isPrivate: boolean, parentPath: string) => void;
  onDeleteFile: (path: string) => void;
  onRenameFile: (oldPath: string, newName: string) => void;
  onQuickRun?: (file: VirtualFile) => void;
}

export const FileManagerView: React.FC<FileManagerViewProps> = ({
  files,
  onUpdateFile,
  onCreateFile,
  onDeleteFile,
  onRenameFile,
  onQuickRun,
}) => {
  const [activeLocation, setActiveLocation] = useState<'home' | 'runtime' | 'files' | 'download'>('home');
  const [selectedFileForEdit, setSelectedFileForEdit] = useState<VirtualFile | null>(null);
  const [editorContent, setEditorContent] = useState('');
  const [activeDetailsFile, setActiveDetailsFile] = useState<VirtualFile | null>(null);
  const [newDialogType, setNewDialogType] = useState<'file' | 'folder' | null>(null);
  const [newItemName, setNewItemName] = useState('');

  const getLocationPath = () => {
    switch (activeLocation) {
      case 'home':
        return '/data/user/0/com.runner.terminal/files/home';
      case 'runtime':
        return '/data/user/0/com.runner.terminal/files/usr/bin';
      case 'files':
        return '/data/user/0/com.runner.terminal/files';
      case 'download':
        return '/sdcard/Download';
    }
  };

  const isCurrentPrivate = activeLocation !== 'download';
  const currentPath = getLocationPath();

  // Filter files in this location
  const currentFiles = files.filter((f) => {
    if (activeLocation === 'home') {
      return f.path.startsWith('/data/user/0/com.runner.terminal/files/home');
    }
    if (activeLocation === 'runtime') {
      return f.path.startsWith('/data/user/0/com.runner.terminal/files/usr');
    }
    if (activeLocation === 'files') {
      return f.path.startsWith('/data/user/0/com.runner.terminal/files');
    }
    return f.path.startsWith('/sdcard/Download');
  });

  const handleOpenFile = (file: VirtualFile) => {
    if (file.isDirectory) return;
    setSelectedFileForEdit(file);
    setEditorContent(file.content || '');
  };

  const handleSaveFile = () => {
    if (selectedFileForEdit) {
      onUpdateFile(selectedFileForEdit.path, editorContent);
      setSelectedFileForEdit(null);
    }
  };

  const handleCreateConfirm = () => {
    if (!newItemName.trim()) return;
    onCreateFile(
      newItemName.trim(),
      newDialogType === 'folder',
      isCurrentPrivate,
      currentPath
    );
    setNewItemName('');
    setNewDialogType(null);
  };

  return (
    <div className="flex flex-col h-full bg-[#0F0D15] text-[#F3EFFC]">
      {/* Location Selector Chips */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#181524] border-b border-[#2F2945] overflow-x-auto">
        <button
          onClick={() => setActiveLocation('home')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition ${
            activeLocation === 'home'
              ? 'bg-[#9205F2] text-white shadow-sm'
              : 'bg-[#221E33] text-[#A89EBF] hover:text-white'
          }`}
        >
          🏠 Runner Home
        </button>

        <button
          onClick={() => setActiveLocation('runtime')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition ${
            activeLocation === 'runtime'
              ? 'bg-[#9205F2] text-white shadow-sm'
              : 'bg-[#221E33] text-[#A89EBF] hover:text-white'
          }`}
        >
          ⚙️ Runtime (usr)
        </button>

        <button
          onClick={() => setActiveLocation('files')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition ${
            activeLocation === 'files'
              ? 'bg-[#9205F2] text-white shadow-sm'
              : 'bg-[#221E33] text-[#A89EBF] hover:text-white'
          }`}
        >
          📁 App Files
        </button>

        <button
          onClick={() => setActiveLocation('download')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition ${
            activeLocation === 'download'
              ? 'bg-[#9205F2] text-white shadow-sm'
              : 'bg-[#221E33] text-[#A89EBF] hover:text-white'
          }`}
        >
          📥 Download / External
        </button>
      </div>

      {/* Breadcrumb Header & Storage Scope Badge */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#181524]/60 border-b border-[#2F2945] text-xs">
        <div className="flex items-center gap-2 font-mono truncate text-[#A89EBF]">
          <span className="text-white font-semibold">{currentPath}</span>
        </div>

        {isCurrentPrivate ? (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#9205F2]/15 border border-[#9205F2]/40 text-[#B347FF] text-[11px] font-medium">
            <Shield className="w-3 h-3" />
            Runner Private Storage
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#38BDF8]/15 border border-[#38BDF8]/40 text-[#38BDF8] text-[11px] font-medium">
            <DownloadCloud className="w-3 h-3" />
            External Storage
          </span>
        )}
      </div>

      {/* Action Toolbar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#0F0D15] border-b border-[#2F2945] text-xs">
        <button
          onClick={() => setNewDialogType('file')}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#221E33] hover:bg-[#2F2945] text-[#F3EFFC] transition"
        >
          <Plus className="w-3.5 h-3.5 text-[#B347FF]" />
          New File
        </button>

        <button
          onClick={() => setNewDialogType('folder')}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#221E33] hover:bg-[#2F2945] text-[#F3EFFC] transition"
        >
          <Plus className="w-3.5 h-3.5 text-[#B347FF]" />
          New Folder
        </button>

        <button
          onClick={() => {
            const runScript = files.find((f) => f.name === 'run.py') || currentFiles.find((f) => f.name.endsWith('.py'));
            if (runScript && onQuickRun) {
              onQuickRun(runScript);
            }
          }}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#34D399]/15 border border-[#34D399]/40 text-[#34D399] hover:bg-[#34D399]/25 transition font-medium"
        >
          <Zap className="w-3.5 h-3.5 text-[#34D399]" />
          Quick Run (run.py)
        </button>
      </div>

      {/* File List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {currentFiles.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-[#6F6687] text-sm">
            <Folder className="w-10 h-10 mb-2 opacity-50" />
            Directory is empty
          </div>
        ) : (
          currentFiles.map((file) => {
            const isPy = file.name.endsWith('.py');
            const isSh = file.name.endsWith('.sh');
            const isCsv = file.name.endsWith('.csv');

            return (
              <div
                key={file.path}
                className="flex items-center justify-between p-3 rounded-xl bg-[#181524] border border-[#2F2945] hover:border-[#9205F2]/50 transition group cursor-pointer"
                onClick={() => handleOpenFile(file)}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                      file.isDirectory
                        ? 'bg-[#9205F2]/20 text-[#B347FF]'
                        : isPy
                        ? 'bg-[#34D399]/20 text-[#34D399]'
                        : isSh
                        ? 'bg-[#FBBF24]/20 text-[#FBBF24]'
                        : 'bg-[#221E33] text-[#A89EBF]'
                    }`}
                  >
                    {file.isDirectory ? (
                      <Folder className="w-5 h-5" />
                    ) : isPy || isSh ? (
                      <FileCode className="w-5 h-5" />
                    ) : (
                      <FileText className="w-5 h-5" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="font-mono text-sm text-[#F3EFFC] truncate font-medium">
                      {file.name}
                    </div>
                    <div className="text-[11px] text-[#A89EBF] mt-0.5">
                      {file.isDirectory ? 'Directory' : `${(file.sizeBytes / 1024).toFixed(1)} KB`}{' '}
                      • {new Date(file.lastModified).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div
                  className="flex items-center gap-1"
                  onClick={(e) => e.stopPropagation()}
                >
                  {(isPy || isSh || file.name.endsWith('.html')) && (
                    <button
                      onClick={() => onQuickRun?.(file)}
                      className="p-1.5 rounded-lg text-[#34D399] bg-[#34D399]/15 hover:bg-[#34D399]/25 transition"
                      title="Quickly Run"
                    >
                      <Play className="w-4 h-4 fill-current" />
                    </button>
                  )}

                  <button
                    onClick={() => handleOpenFile(file)}
                    className="p-1.5 rounded-lg text-[#A89EBF] hover:text-[#B347FF] hover:bg-[#221E33] transition"
                    title="Edit/View"
                  >
                    <Edit className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => setActiveDetailsFile(file)}
                    className="p-1.5 rounded-lg text-[#A89EBF] hover:text-[#38BDF8] hover:bg-[#221E33] transition"
                    title="Info"
                  >
                    <Info className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onDeleteFile(file.path)}
                    className="p-1.5 rounded-lg text-[#A89EBF] hover:text-[#F87171] hover:bg-[#221E33] transition"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Text Editor Modal */}
      {selectedFileForEdit && (
        <div className="fixed inset-0 z-50 bg-black/80 flex flex-col p-4">
          <div className="flex items-center justify-between px-4 py-3 bg-[#181524] border border-[#2F2945] rounded-t-xl">
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4 text-[#B347FF]" />
              <span className="font-mono text-sm font-semibold text-[#F3EFFC]">
                {selectedFileForEdit.name}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setSelectedFileForEdit(null)}
                className="px-3 py-1.5 rounded-lg bg-[#221E33] text-xs text-[#A89EBF] hover:text-white"
              >
                Close
              </button>
              <button
                onClick={handleSaveFile}
                className="flex items-center gap-1 px-4 py-1.5 rounded-lg bg-[#9205F2] hover:bg-[#B347FF] text-xs font-semibold text-white shadow"
              >
                <Save className="w-3.5 h-3.5" />
                Save Changes
              </button>
            </div>
          </div>

          <textarea
            value={editorContent}
            onChange={(e) => setEditorContent(e.target.value)}
            className="flex-1 w-full bg-[#0F0D15] text-[#F3EFFC] font-mono text-xs p-4 border-x border-b border-[#2F2945] rounded-b-xl outline-none resize-none leading-relaxed"
            spellCheck={false}
          />
        </div>
      )}

      {/* New File/Folder Modal */}
      {newDialogType && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#181524] border border-[#2F2945] rounded-2xl p-5 max-w-sm w-full">
            <h3 className="text-base font-bold text-[#F3EFFC]">
              Create New {newDialogType === 'folder' ? 'Folder' : 'File'}
            </h3>
            <p className="text-xs text-[#A89EBF] mt-1">
              Will be placed in {isCurrentPrivate ? 'Runner Private Home' : 'Download Storage'}
            </p>

            <input
              type="text"
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder={newDialogType === 'folder' ? 'my_project' : 'script.py'}
              className="w-full mt-4 px-3 py-2 rounded-xl bg-[#0F0D15] border border-[#2F2945] font-mono text-sm text-[#F3EFFC] outline-none focus:border-[#9205F2]"
              autoFocus
            />

            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                onClick={() => setNewDialogType(null)}
                className="px-4 py-2 rounded-xl bg-[#221E33] text-xs text-[#A89EBF] hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateConfirm}
                className="px-4 py-2 rounded-xl bg-[#9205F2] hover:bg-[#B347FF] text-xs font-semibold text-white"
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}

      {/* File Details Modal */}
      {activeDetailsFile && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#181524] border border-[#2F2945] rounded-2xl p-5 max-w-sm w-full">
            <h3 className="text-base font-bold text-[#F3EFFC]">File Information</h3>
            <div className="mt-3 space-y-2 text-xs font-mono text-[#A89EBF]">
              <div>
                <span className="text-[#6F6687] block">Name:</span>
                <span className="text-[#F3EFFC]">{activeDetailsFile.name}</span>
              </div>
              <div>
                <span className="text-[#6F6687] block">Full Path:</span>
                <span className="text-[#38BDF8] break-all">{activeDetailsFile.path}</span>
              </div>
              <div>
                <span className="text-[#6F6687] block">Size:</span>
                <span className="text-[#F3EFFC]">
                  {(activeDetailsFile.sizeBytes / 1024).toFixed(2)} KB ({activeDetailsFile.sizeBytes} bytes)
                </span>
              </div>
              <div>
                <span className="text-[#6F6687] block">Storage Class:</span>
                <span className="text-[#B347FF]">
                  {activeDetailsFile.isPrivate ? 'Application Private Sandbox' : 'Scoped External (Download)'}
                </span>
              </div>
            </div>

            <button
              onClick={() => setActiveDetailsFile(null)}
              className="w-full mt-5 py-2 rounded-xl bg-[#221E33] hover:bg-[#2F2945] text-xs font-semibold text-[#F3EFFC]"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
