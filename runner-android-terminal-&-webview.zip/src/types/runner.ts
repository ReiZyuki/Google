export interface VirtualFile {
  name: string;
  path: string;
  isDirectory: boolean;
  sizeBytes: number;
  lastModified: number;
  isPrivate: boolean;
  content?: string;
}

export interface DetectedServer {
  originalUrl: string;
  normalizedUrl: string;
  host: string;
  port: number;
  ready: boolean;
}

export interface AppSettings {
  theme: 'dark' | 'light' | 'system';
  autoOpenWebView: boolean;
  floatingBallEnabled: boolean;
  serverTimeoutSeconds: number;
  terminalFontSize: number;
}
