import React, { useState } from 'react';
import {
  Terminal as TerminalIcon,
  Folder,
  Globe,
  Settings as SettingsIcon,
  Code2,
  Smartphone,
  Maximize2,
  Shield,
  Circle,
} from 'lucide-react';
import { TerminalView } from './components/TerminalView';
import { FileManagerView } from './components/FileManagerView';
import { WebViewScreen } from './components/WebViewScreen';
import { SettingsView } from './components/SettingsView';
import { ProjectCodeViewer } from './components/ProjectCodeViewer';
import { FloatingBallOverlay } from './components/FloatingBallOverlay';
import { INITIAL_FILES } from './data/mockFiles';
import { DetectedServer, AppSettings, VirtualFile } from './types/runner';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'terminal' | 'files' | 'webview' | 'settings' | 'sources'>('terminal');
  const [activeServer, setActiveServer] = useState<DetectedServer | null>(null);
  const [isServerRunning, setIsServerRunning] = useState(false);
  const [files, setFiles] = useState<VirtualFile[]>(INITIAL_FILES);
  const [isPhoneFrame, setIsPhoneFrame] = useState(false);

  const [settings, setSettings] = useState<AppSettings>({
    theme: 'dark',
    autoOpenWebView: true,
    floatingBallEnabled: true,
    serverTimeoutSeconds: 5,
    terminalFontSize: 13,
  });

  const handleStartServer = () => {
    setIsServerRunning(true);
    setActiveServer({
      originalUrl: 'http://127.0.0.1:5000',
      normalizedUrl: 'http://127.0.0.1:5000',
      host: '127.0.0.1',
      port: 5000,
      ready: true,
    });
  };

  const handleStopServer = () => {
    setIsServerRunning(false);
  };

  const handleQuickRun = (file: VirtualFile) => {
    if (file.name.endsWith('.html')) {
      handleOpenWebView('http://127.0.0.1:5000');
      return;
    }

    // Quick run starts the server / process and transitions
    handleStartServer();
    if (settings.autoOpenWebView) {
      setTimeout(() => {
        setCurrentTab('webview');
      }, 700);
    } else {
      setCurrentTab('terminal');
    }
  };

  const handleOpenWebView = (url: string) => {
    setActiveServer({
      originalUrl: url,
      normalizedUrl: url,
      host: '127.0.0.1',
      port: 5000,
      ready: true,
    });
    setCurrentTab('webview');
  };

  const handleUpdateFile = (path: string, content: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.path === path ? { ...f, content, sizeBytes: content.length, lastModified: Date.now() } : f))
    );
  };

  const handleCreateFile = (name: string, isDir: boolean, isPrivate: boolean, parentPath: string) => {
    const newFile: VirtualFile = {
      name,
      path: `${parentPath}/${name}`,
      isDirectory: isDir,
      sizeBytes: isDir ? 4096 : 0,
      lastModified: Date.now(),
      isPrivate,
      content: isDir ? undefined : '# New script created in Runner\n',
    };
    setFiles((prev) => [...prev, newFile]);
  };

  const handleDeleteFile = (path: string) => {
    setFiles((prev) => prev.filter((f) => f.path !== path));
  };

  const handleRenameFile = (oldPath: string, newName: string) => {
    setFiles((prev) =>
      prev.map((f) => {
        if (f.path === oldPath) {
          const dir = oldPath.substring(0, oldPath.lastIndexOf('/'));
          return { ...f, name: newName, path: `${dir}/${newName}` };
        }
        return f;
      })
    );
  };

  return (
    <div
      className={`min-h-screen flex flex-col items-center justify-center p-0 md:p-6 transition-colors ${
        settings.theme === 'light' ? 'bg-[#F4F1FA] text-[#1D152B]' : 'bg-[#0A080F] text-[#F3EFFC]'
      }`}
    >
      {/* Top Bar with Mode Toggles */}
      <header className="w-full max-w-4xl flex items-center justify-between px-4 py-3 mb-2">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#9205F2] flex items-center justify-center shadow-lg shadow-[#9205F2]/25">
            <TerminalIcon className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-wide text-sm font-sans text-[#F3EFFC]">RUNNER</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#9205F2]/20 text-[#B347FF] border border-[#9205F2]/40">
                Android 9+ (ARM64)
              </span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {isServerRunning && activeServer && (
            <button
              onClick={() => setCurrentTab('webview')}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#181524] border border-[#34D399]/40 text-[#34D399] text-xs font-mono hover:bg-[#181524]/80 transition shadow-sm"
              title="Click to switch to active Flask server in WebView"
            >
              <span className="w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
              <span>:{activeServer.port} Online</span>
            </button>
          )}

          <button
            onClick={() => setCurrentTab('sources')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition ${
              currentTab === 'sources'
                ? 'bg-[#9205F2] border-[#9205F2] text-white shadow-md'
                : 'bg-[#181524] border-[#2F2945] text-[#A89EBF] hover:text-white'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Android Sources</span>
          </button>

          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="p-1.5 rounded-xl bg-[#181524] border border-[#2F2945] text-[#A89EBF] hover:text-white transition"
            title={isPhoneFrame ? 'Full View' : 'Device Frame View'}
          >
            {isPhoneFrame ? <Maximize2 className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Runner App Device Container */}
      <main
        className={`w-full bg-[#0F0D15] overflow-hidden flex flex-col transition-all duration-300 ${
          isPhoneFrame
            ? 'max-w-md h-[780px] rounded-[36px] border-[8px] border-[#181524] shadow-2xl ring-1 ring-[#2F2945]'
            : 'max-w-4xl h-[700px] rounded-2xl border border-[#2F2945] shadow-2xl'
        }`}
      >
        {/* Android Native Status Bar Simulation */}
        <div className="flex items-center justify-between px-5 py-2 bg-[#181524] border-b border-[#2F2945]/60 text-[11px] font-mono text-[#A89EBF] select-none">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#F3EFFC]">01:30</span>
            <span className="text-[10px] text-[#6F6687]">•</span>
            <span className="text-[#B347FF] font-sans font-semibold text-[11px]">Runner OS</span>
          </div>

          <div className="flex items-center gap-3">
            {isServerRunning && (
              <span className="flex items-center gap-1 text-[#34D399] text-[10px]">
                <Circle className="w-2 h-2 fill-current" />
                PID: 2841
              </span>
            )}
            <span className="text-[#A89EBF]">ARM64</span>
            <span className="text-[#34D399]">100%</span>
          </div>
        </div>

        {/* Content View Routing */}
        <div className="flex-1 overflow-hidden relative">
          {currentTab === 'terminal' && (
            <TerminalView
              activeServer={activeServer}
              isRunning={isServerRunning}
              onStartServer={handleStartServer}
              onStopServer={handleStopServer}
              onOpenWebView={handleOpenWebView}
              settings={settings}
            />
          )}

          {currentTab === 'files' && (
            <FileManagerView
              files={files}
              onUpdateFile={handleUpdateFile}
              onCreateFile={handleCreateFile}
              onDeleteFile={handleDeleteFile}
              onRenameFile={handleRenameFile}
              onQuickRun={handleQuickRun}
            />
          )}

          {currentTab === 'webview' && (
            <WebViewScreen
              server={activeServer}
              isRunning={isServerRunning}
              onReturnToTerminal={() => setCurrentTab('terminal')}
              onClose={() => setCurrentTab('terminal')}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={(updated) => setSettings((s) => ({ ...s, ...updated }))}
            />
          )}

          {currentTab === 'sources' && <ProjectCodeViewer />}

          {/* Floating Ball Overlay (when enabled) */}
          {settings.floatingBallEnabled && currentTab !== 'sources' && (
            <FloatingBallOverlay
              isServerRunning={isServerRunning}
              onNavigateTab={(tab) => setCurrentTab(tab)}
              onStopServer={handleStopServer}
              onDismiss={() => setSettings((s) => ({ ...s, floatingBallEnabled: false }))}
            />
          )}
        </div>

        {/* Bottom Navigation Bar */}
        <nav className="flex items-center justify-around px-2 py-2 bg-[#181524] border-t border-[#2F2945] select-none">
          <button
            onClick={() => setCurrentTab('terminal')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition ${
              currentTab === 'terminal'
                ? 'text-[#B347FF] font-semibold'
                : 'text-[#6F6687] hover:text-[#A89EBF]'
            }`}
          >
            <TerminalIcon className="w-5 h-5" />
            <span className="text-[11px]">Terminal</span>
          </button>

          <button
            onClick={() => setCurrentTab('files')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition ${
              currentTab === 'files'
                ? 'text-[#B347FF] font-semibold'
                : 'text-[#6F6687] hover:text-[#A89EBF]'
            }`}
          >
            <Folder className="w-5 h-5" />
            <span className="text-[11px]">Files</span>
          </button>

          <button
            onClick={() => setCurrentTab('webview')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl relative transition ${
              currentTab === 'webview'
                ? 'text-[#B347FF] font-semibold'
                : 'text-[#6F6687] hover:text-[#A89EBF]'
            }`}
          >
            {isServerRunning && (
              <span className="absolute top-1 right-3 w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
            )}
            <Globe className="w-5 h-5" />
            <span className="text-[11px]">WebView</span>
          </button>

          <button
            onClick={() => setCurrentTab('settings')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition ${
              currentTab === 'settings'
                ? 'text-[#B347FF] font-semibold'
                : 'text-[#6F6687] hover:text-[#A89EBF]'
            }`}
          >
            <SettingsIcon className="w-5 h-5" />
            <span className="text-[11px]">Settings</span>
          </button>
        </nav>
      </main>
    </div>
  );
}
