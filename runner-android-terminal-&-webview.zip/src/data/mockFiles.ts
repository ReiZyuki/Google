import { VirtualFile } from '../types/runner';

export const INITIAL_FILES: VirtualFile[] = [
  // Runner Private Home
  {
    name: 'run.py',
    path: '/data/user/0/com.runner.terminal/files/home/run.py',
    isDirectory: false,
    sizeBytes: 1840,
    lastModified: Date.now() - 3600000,
    isPrivate: true,
    content: `#!/usr/bin/env python3
"""
Runner Sample Local Server
Demonstrates automatic localhost URL detection and built-in WebView.
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
import sys

PORT = 5000
HOST = "127.0.0.1"

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Runner Flask Local Server</title>
  <style>
    body {
      margin: 0;
      padding: 24px;
      font-family: system-ui, -apple-system, sans-serif;
      background: #0F0D15;
      color: #F3EFFC;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 80vh;
      text-align: center;
    }
    .card {
      background: #181524;
      border: 1px solid #2F2945;
      border-radius: 16px;
      padding: 28px;
      max-width: 440px;
      box-shadow: 0 12px 32px rgba(0,0,0,0.5);
    }
    h1 { color: #B347FF; margin: 0 0 12px 0; font-size: 22px; }
    .badge {
      display: inline-block;
      background: rgba(146, 5, 242, 0.18);
      border: 1px solid #9205F2;
      color: #B347FF;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 12px;
      margin-bottom: 16px;
      font-weight: 600;
    }
    p { color: #A89EBF; font-size: 14px; line-height: 1.6; }
    .counter-box {
      margin: 20px 0;
      padding: 14px;
      background: #0F0D15;
      border-radius: 12px;
      border: 1px solid #2F2945;
    }
    .btn {
      background: #9205F2;
      color: white;
      border: none;
      padding: 10px 22px;
      border-radius: 24px;
      font-weight: 600;
      cursor: pointer;
      transition: opacity 0.2s;
    }
    .btn:hover { opacity: 0.9; }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">Runner Embedded WebView</div>
    <h1>Flask Server Online!</h1>
    <p>Runner detected the local HTTP URL from terminal output and opened it directly in the integrated WebView without leaving the app.</p>
    <div class="counter-box">
      <div style="font-size: 12px; color: #6F6687;">SERVER METRICS</div>
      <div style="font-size: 20px; font-weight: bold; color: #34D399; margin-top: 4px;">HOST: 127.0.0.1:5000</div>
      <div id="clickCount" style="margin-top: 6px; font-size: 14px; color: #A89EBF;">Interactive requests: 0</div>
    </div>
    <button class="btn" onclick="increment()">Send Test Request</button>
  </div>
  <script>
    let count = 0;
    function increment() {
      count++;
      document.getElementById('clickCount').innerText = 'Interactive requests: ' + count;
    }
  </script>
</body>
</html>"""

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(HTML_TEMPLATE.encode("utf-8"))

    def log_message(self, format, *args):
        sys.stderr.write("%s - - [%s] %s\\n" % (self.address_string(), self.log_date_time_string(), format % args))

if __name__ == "__main__":
    print(" * Serving Runner Python Application")
    print(" * Environment: production")
    print(" * Runner Private Storage: %s" % sys.path[0])
    print(" * Running on http://127.0.0.1:%d (Press CTRL+C to quit)" % PORT)
    sys.stdout.flush()
    server = HTTPServer((HOST, PORT), Handler)
    server.serve_forever()
`
  },
  {
    name: '.bashrc',
    path: '/data/user/0/com.runner.terminal/files/home/.bashrc',
    isDirectory: false,
    sizeBytes: 240,
    lastModified: Date.now() - 7200000,
    isPrivate: true,
    content: `# Runner Shell Environment
export HOME="/data/user/0/com.runner.terminal/files/home"
export PREFIX="/data/user/0/com.runner.terminal/files/usr"
export PATH="$PREFIX/bin:/system/bin:$PATH"
export TMPDIR="/data/user/0/com.runner.terminal/cache/tmp"
export PS1="runner@localhost:~ $ "
`
  },
  {
    name: 'README.txt',
    path: '/data/user/0/com.runner.terminal/files/home/README.txt',
    isDirectory: false,
    sizeBytes: 420,
    lastModified: Date.now() - 10800000,
    isPrivate: true,
    content: `Welcome to Runner!
A Termux-style terminal application with built-in WebView and automatic localhost URL detection.

Commands:
- Type 'python run.py' to launch the sample server
- Runner will automatically detect http://127.0.0.1:5000 and open the built-in WebView!
- Tap 'Stop (Ctrl+C)' to terminate the process
`
  },
  // Runtime usr/bin
  {
    name: 'python3',
    path: '/data/user/0/com.runner.terminal/files/usr/bin/python3',
    isDirectory: false,
    sizeBytes: 14500,
    lastModified: Date.now() - 86400000,
    isPrivate: true,
    content: '#!/system/bin/sh\n# Python runtime launcher binary'
  },
  {
    name: 'sh',
    path: '/data/user/0/com.runner.terminal/files/usr/bin/sh',
    isDirectory: false,
    sizeBytes: 89000,
    lastModified: Date.now() - 86400000,
    isPrivate: true,
    content: '#!/system/bin/sh\n# Shell binary'
  },
  {
    name: 'curl',
    path: '/data/user/0/com.runner.terminal/files/usr/bin/curl',
    isDirectory: false,
    sizeBytes: 32000,
    lastModified: Date.now() - 86400000,
    isPrivate: true,
    content: '#!/system/bin/sh\n# HTTP client utility'
  },
  // External Download files
  {
    name: 'sample_dataset.csv',
    path: '/sdcard/Download/sample_dataset.csv',
    isDirectory: false,
    sizeBytes: 4890,
    lastModified: Date.now() - 43200000,
    isPrivate: false,
    content: 'id,item,price,category\n1,Keyboard,49.99,Hardware\n2,Display,199.99,Hardware\n3,Terminal Script,0.00,Software'
  },
  {
    name: 'server_config.json',
    path: '/sdcard/Download/server_config.json',
    isDirectory: false,
    sizeBytes: 310,
    lastModified: Date.now() - 21600000,
    isPrivate: false,
    content: '{\n  "port": 5000,\n  "host": "127.0.0.1",\n  "debug": false,\n  "appName": "RunnerServer"\n}'
  }
];
