package com.runner.terminal.ui.files

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.recyclerview.widget.RecyclerView
import com.runner.terminal.R
import com.runner.terminal.databinding.ItemFileBinding
import com.runner.terminal.storage.FileItem

class FileAdapter(
    private val onItemClick: (FileItem) -> Unit,
    private val onOptionsClick: (FileItem, PopupMenu) -> Unit,
    private val onQuickRunClick: ((FileItem) -> Unit)? = null
) : RecyclerView.Adapter<FileAdapter.FileViewHolder>() {

    private val items = mutableListOf<FileItem>()

    fun submitList(newItems: List<FileItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val binding = ItemFileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FileViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class FileViewHolder(private val binding: ItemFileBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: FileItem) {
            binding.tvFileName.text = item.name
            binding.tvFileDetails.text = "${item.formattedSize} • ${item.formattedDate}"

            val isRunnable = !item.isDirectory && (item.name.endsWith(".py") || item.name.endsWith(".sh") || item.name.endsWith(".html") || item.name.endsWith(".js"))

            if (item.isDirectory) {
                binding.ivFileIcon.setImageResource(android.R.drawable.ic_menu_agenda)
                binding.ivFileIcon.setColorFilter(
                    itemView.context.getColor(R.color.runner_purple_light)
                )
                binding.btnQuickRun.visibility = View.GONE
            } else {
                val isPy = item.name.endsWith(".py")
                val isSh = item.name.endsWith(".sh")
                binding.ivFileIcon.setImageResource(android.R.drawable.ic_menu_edit)
                binding.ivFileIcon.setColorFilter(
                    itemView.context.getColor(
                        if (isPy) R.color.terminal_green else if (isSh) R.color.terminal_yellow else R.color.runner_text_secondary_dark
                    )
                )

                if (isRunnable) {
                    binding.btnQuickRun.visibility = View.VISIBLE
                    binding.btnQuickRun.setOnClickListener { onQuickRunClick?.invoke(item) }
                } else {
                    binding.btnQuickRun.visibility = View.GONE
                }
            }

            itemView.setOnClickListener { onItemClick(item) }

            binding.btnFileOptions.setOnClickListener { view ->
                val popup = PopupMenu(view.context, view)
                if (isRunnable) {
                    popup.menu.add("⚡ Quickly Run")
                }
                popup.menu.add("Open / Edit")
                popup.menu.add("Rename")
                popup.menu.add("Delete")
                popup.menu.add("Details")
                onOptionsClick(item, popup)
                popup.show()
            }
        }
    }
}
