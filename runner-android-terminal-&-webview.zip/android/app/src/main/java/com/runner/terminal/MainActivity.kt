package com.runner.terminal

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.runner.terminal.databinding.ActivityMainBinding
import com.runner.terminal.network.DetectedLocalServer
import com.runner.terminal.process.ProcessState
import com.runner.terminal.process.RunnerProcessManager
import com.runner.terminal.service.RunnerForegroundService
import com.runner.terminal.ui.files.FileManagerFragment
import com.runner.terminal.ui.settings.SettingsFragment
import com.runner.terminal.ui.terminal.TerminalFragment
import com.runner.terminal.ui.webview.RunnerWebViewFragment

class MainActivity : AppCompatActivity(), RunnerProcessManager.ProcessEventListener {

    private lateinit var binding: ActivityMainBinding

    private val terminalFragment = TerminalFragment()
    private val fileManagerFragment = FileManagerFragment()
    private var webViewFragment: RunnerWebViewFragment? = null
    private val settingsFragment = SettingsFragment()

    private var activeFragment: Fragment = terminalFragment
    private val processManager = RunnerProcessManager.instance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupFragments(savedInstanceState)
        setupNavigation()
        setupBackPress()

        handleNavIntent(intent)

        processManager.addListener(this)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleNavIntent(intent)
    }

    private fun handleNavIntent(intent: Intent?) {
        val targetTab = intent?.getStringExtra(EXTRA_TARGET_TAB) ?: return
        when (targetTab) {
            "terminal" -> navigateToTerminal()
            "webview" -> {
                val url = intent.getStringExtra(EXTRA_TARGET_URL)
                    ?: processManager.activeDetectedServer?.normalizedUrl
                    ?: "http://127.0.0.1:5000"
                openWebView(url)
            }
            "files" -> {
                switchFragment(fileManagerFragment, TAG_FILES)
                binding.bottomNavView.selectedItemId = R.id.action_files
            }
            "settings" -> {
                switchFragment(settingsFragment, TAG_SETTINGS)
                binding.bottomNavView.selectedItemId = R.id.action_settings
            }
        }
    }

    private fun setupFragments(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.fragmentContainer, terminalFragment, TAG_TERMINAL)
                .commit()
            activeFragment = terminalFragment
        }
    }

    private fun setupNavigation() {
        binding.bottomNavView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.action_terminal -> {
                    switchFragment(terminalFragment, TAG_TERMINAL)
                    true
                }
                R.id.action_files -> {
                    switchFragment(fileManagerFragment, TAG_FILES)
                    true
                }
                R.id.action_webview -> {
                    val url = processManager.activeDetectedServer?.normalizedUrl ?: "http://127.0.0.1:5000"
                    openWebView(url)
                    true
                }
                R.id.action_settings -> {
                    switchFragment(settingsFragment, TAG_SETTINGS)
                    true
                }
                else -> false
            }
        }

        binding.activeServerBadge.setOnClickListener {
            val server = processManager.activeDetectedServer
            if (server != null) {
                openWebView(server.normalizedUrl)
            }
        }
    }

    fun openWebView(url: String) {
        val existing = supportFragmentManager.findFragmentByTag(TAG_WEBVIEW) as? RunnerWebViewFragment
        val target = existing ?: RunnerWebViewFragment.newInstance(url).also { webViewFragment = it }

        if (existing != null) {
            existing.loadTargetUrl(url)
        }

        switchFragment(target, TAG_WEBVIEW)
        binding.bottomNavView.selectedItemId = R.id.action_webview
    }

    fun navigateToTerminal() {
        switchFragment(terminalFragment, TAG_TERMINAL)
        binding.bottomNavView.selectedItemId = R.id.action_terminal
    }

    private fun switchFragment(target: Fragment, tag: String) {
        if (target == activeFragment && target.isAdded) return

        val transaction = supportFragmentManager.beginTransaction()

        if (!target.isAdded) {
            transaction.hide(activeFragment).add(R.id.fragmentContainer, target, tag)
        } else {
            transaction.hide(activeFragment).show(target)
        }

        transaction.commit()
        activeFragment = target
    }

    private fun setupBackPress() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (activeFragment is RunnerWebViewFragment) {
                    navigateToTerminal()
                } else if (activeFragment != terminalFragment) {
                    navigateToTerminal()
                } else {
                    finish()
                }
            }
        })
    }

    override fun onOutputLine(line: String) {
        // Output handled by TerminalFragment directly
    }

    override fun onStateChanged(state: ProcessState) {
        runOnUiThread {
            when (state) {
                is ProcessState.Running -> {
                    RunnerForegroundService.start(this, state.command)
                }
                is ProcessState.Completed -> {
                    binding.activeServerBadge.visibility = View.GONE
                    RunnerForegroundService.stop(this)
                }
                else -> {}
            }
        }
    }

    override fun onLocalServerReady(server: DetectedLocalServer) {
        runOnUiThread {
            binding.activeServerBadge.visibility = View.VISIBLE
            binding.tvActiveServerUrl.text = ":${server.port}"

            // Automatically switch to WebView as requested in Feature 7 & 8
            openWebView(server.normalizedUrl)
        }
    }

    override fun onLocalServerStopped() {
        runOnUiThread {
            binding.activeServerBadge.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        processManager.removeListener(this)
    }

    companion object {
        const val EXTRA_TARGET_TAB = "extra_target_tab"
        const val EXTRA_TARGET_URL = "extra_target_url"

        private const val TAG_TERMINAL = "tag_terminal"
        private const val TAG_FILES = "tag_files"
        private const val TAG_WEBVIEW = "tag_webview"
        private const val TAG_SETTINGS = "tag_settings"
    }
}
