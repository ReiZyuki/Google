package com.runner.terminal.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.runner.terminal.R
import com.runner.terminal.RunnerApplication
import com.runner.terminal.data.PreferencesManager
import com.runner.terminal.databinding.FragmentSettingsBinding
import com.runner.terminal.service.FloatingBallService

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private val prefs get() = RunnerApplication.instance.preferencesManager
    private val storage get() = RunnerApplication.instance.storageManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        populatePreferences()
        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        // Re-verify overlay permission status in case user granted it in Settings
        if (_binding != null) {
            val hasPermission = Settings.canDrawOverlays(requireContext())
            if (prefs.floatingBallEnabled && !hasPermission) {
                prefs.floatingBallEnabled = false
                binding.switchFloatingBall.isChecked = false
            }
        }
    }

    private fun populatePreferences() {
        // Theme
        when (prefs.themeMode) {
            PreferencesManager.THEME_LIGHT -> binding.rbThemeLight.isChecked = true
            PreferencesManager.THEME_SYSTEM -> binding.rbThemeSystem.isChecked = true
            else -> binding.rbThemeDark.isChecked = true
        }

        // Auto-open WebView
        binding.switchAutoOpenWebView.isChecked = prefs.autoOpenWebView

        // Floating Ball
        binding.switchFloatingBall.isChecked = prefs.floatingBallEnabled && Settings.canDrawOverlays(requireContext())

        // Timeout
        binding.sliderServerTimeout.value = prefs.serverTimeoutSeconds.toFloat().coerceIn(2f, 15f)

        // Terminal font size
        binding.sliderTerminalFontSize.value = prefs.terminalFontSize.coerceIn(10f, 20f)

        // Storage Paths
        binding.tvStoragePathsInfo.text = """
        HOME: ${storage.homeDir.absolutePath}
        PREFIX: ${storage.usrDir.absolutePath}
        BIN: ${storage.binDir.absolutePath}
        TMP: ${storage.tmpDir.absolutePath}
        DOWNLOAD: ${storage.externalDownloadDir?.absolutePath ?: "N/A"}
        """.trimIndent()
    }

    private fun setupListeners() {
        binding.rgThemeMode.setOnCheckedChangeListener { _, checkedId ->
            val newTheme = when (checkedId) {
                R.id.rbThemeLight -> PreferencesManager.THEME_LIGHT
                R.id.rbThemeSystem -> PreferencesManager.THEME_SYSTEM
                else -> PreferencesManager.THEME_DARK
            }
            prefs.themeMode = newTheme
            RunnerApplication.instance.applyAppTheme(newTheme)
        }

        binding.switchAutoOpenWebView.setOnCheckedChangeListener { _, isChecked ->
            prefs.autoOpenWebView = isChecked
        }

        binding.switchFloatingBall.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!Settings.canDrawOverlays(requireContext())) {
                    Toast.makeText(
                        requireContext(),
                        "Please grant 'Display over other apps' permission for Runner",
                        Toast.LENGTH_LONG
                    ).show()
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${requireContext().packageName}")
                    )
                    startActivity(intent)
                    binding.switchFloatingBall.isChecked = false
                    prefs.floatingBallEnabled = false
                } else {
                    prefs.floatingBallEnabled = true
                    FloatingBallService.start(requireContext())
                    Toast.makeText(requireContext(), "Floating Ball activated", Toast.LENGTH_SHORT).show()
                }
            } else {
                prefs.floatingBallEnabled = false
                FloatingBallService.stop(requireContext())
            }
        }

        binding.sliderServerTimeout.addOnChangeListener { _, value, _ ->
            prefs.serverTimeoutSeconds = value.toInt()
        }

        binding.sliderTerminalFontSize.addOnChangeListener { _, value, _ ->
            prefs.terminalFontSize = value
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
