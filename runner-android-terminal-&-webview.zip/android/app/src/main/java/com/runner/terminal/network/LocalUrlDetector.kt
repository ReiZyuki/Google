package com.runner.terminal.network

import java.net.URI
import java.util.regex.Pattern

data class DetectedLocalServer(
    val originalUrl: String,
    val normalizedUrl: String,
    val host: String,
    val port: Int
)

class LocalUrlDetector {

    // Regex matching standard HTTP/HTTPS URLs with localhost, 127.0.0.1, 0.0.0.0, or [::1]
    private val localUrlPattern = Pattern.compile(
        "https?://(?:localhost|127\\.0\\.0\\.1|0\\.0\\.0\\.0|\\[::1\\])(?::([0-9]{1,5}))?(?:/[a-zA-Z0-9_.~!*'();:@&=+\$,/?#-]*)?",
        Pattern.CASE_INSENSITIVE
    )

    /**
     * Inspects text for localhost server URLs.
     * Returns the first valid, trusted local server found, or null.
     */
    fun findLocalServerUrl(text: String): DetectedLocalServer? {
        val matcher = localUrlPattern.matcher(text)
        while (matcher.find()) {
            val rawUrl = matcher.group() ?: continue
            val detected = parseAndNormalize(rawUrl)
            if (detected != null && isTrustedLocalAddress(detected.host)) {
                return detected
            }
        }
        return null
    }

    /**
     * Normalizes 0.0.0.0 to 127.0.0.1 so the Android WebView can connect to the loopback socket.
     */
    fun parseAndNormalize(urlStr: String): DetectedLocalServer? {
        return try {
            val uri = URI(urlStr)
            val scheme = uri.scheme?.lowercase() ?: "http"
            val host = uri.host?.lowercase() ?: return null
            val port = if (uri.port != -1) uri.port else 80
            val path = if (uri.rawPath.isNullOrEmpty()) "/" else uri.rawPath

            // Security constraint: only allow HTTP or HTTPS
            if (scheme != "http" && scheme != "https") return null

            // Security constraint: port must be valid
            if (port <= 0 || port > 65535) return null

            // Normalize 0.0.0.0 or [::1] to 127.0.0.1 for WebView loopback compatibility
            val normalizedHost = when (host) {
                "0.0.0.0" -> "127.0.0.1"
                "[::1]", "::1" -> "127.0.0.1"
                else -> host
            }

            val normalizedUrl = "$scheme://$normalizedHost:$port$path"
            DetectedLocalServer(
                originalUrl = urlStr,
                normalizedUrl = normalizedUrl,
                host = normalizedHost,
                port = port
            )
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Strict security validation: ONLY automatically trust local loopback addresses.
     * External addresses (e.g. google.com, 192.168.x.x, etc.) are rejected for auto-open.
     */
    fun isTrustedLocalAddress(host: String): Boolean {
        val cleanHost = host.lowercase().trim()
        return cleanHost == "127.0.0.1" ||
                cleanHost == "localhost" ||
                cleanHost == "0.0.0.0" ||
                cleanHost == "::1" ||
                cleanHost == "[::1]"
    }
}
