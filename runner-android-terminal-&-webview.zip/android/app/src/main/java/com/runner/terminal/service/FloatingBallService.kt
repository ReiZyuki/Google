package com.runner.terminal.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.runner.terminal.MainActivity
import com.runner.terminal.databinding.LayoutFloatingBallBinding
import com.runner.terminal.network.DetectedLocalServer
import com.runner.terminal.process.ProcessState
import com.runner.terminal.process.RunnerProcessManager
import kotlin.math.abs

class FloatingBallService : Service(), RunnerProcessManager.ProcessEventListener {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var _binding: LayoutFloatingBallBinding? = null
    private val binding get() = _binding!!

    private lateinit var layoutParams: WindowManager.LayoutParams
    private val processManager = RunnerProcessManager.instance

    private var isMenuExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        // Check overlay permission
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        _binding = LayoutFloatingBallBinding.inflate(LayoutInflater.from(this))
        floatingView = binding.root

        setupLayoutParams()
        setupTouchListener()
        setupMenuActions()

        try {
            windowManager?.addView(floatingView, layoutParams)
        } catch (e: Exception) {
            stopSelf()
            return
        }

        processManager.addListener(this)
        updateStatusBadge()
    }

    private fun setupLayoutParams() {
        val layoutType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 260
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouchListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = true

        binding.flFloatingBallHead.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()

                    if (abs(deltaX) > 12 || abs(deltaY) > 12) {
                        isClick = false
                    }

                    layoutParams.x = initialX + deltaX
                    layoutParams.y = initialY + deltaY
                    windowManager?.updateViewLayout(floatingView, layoutParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        toggleMenu()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleMenu() {
        isMenuExpanded = !isMenuExpanded
        binding.layoutFloatingMenu.visibility = if (isMenuExpanded) View.VISIBLE else View.GONE
    }

    private fun setupMenuActions() {
        binding.btnFloatingTerminal.setOnClickListener {
            toggleMenu()
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(MainActivity.EXTRA_TARGET_TAB, "terminal")
            }
            startActivity(intent)
        }

        binding.btnFloatingWebView.setOnClickListener {
            toggleMenu()
            val serverUrl = processManager.activeDetectedServer?.normalizedUrl ?: "http://127.0.0.1:5000"
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(MainActivity.EXTRA_TARGET_TAB, "webview")
                putExtra(MainActivity.EXTRA_TARGET_URL, serverUrl)
            }
            startActivity(intent)
        }

        binding.btnFloatingStopProcess.setOnClickListener {
            processManager.terminateActiveProcess()
            toggleMenu()
        }

        binding.btnFloatingCloseBall.setOnClickListener {
            stopSelf()
        }
    }

    private fun updateStatusBadge() {
        val server = processManager.activeDetectedServer
        if (server != null && processManager.isRunning()) {
            binding.viewServerPulseDot.visibility = View.VISIBLE
            binding.tvFloatingWebTitle.text = "Open WebView (:${server.port})"
        } else {
            binding.viewServerPulseDot.visibility = View.GONE
            binding.tvFloatingWebTitle.text = "Open WebView"
        }
    }

    override fun onOutputLine(line: String) {}

    override fun onStateChanged(state: ProcessState) {
        floatingView?.post {
            updateStatusBadge()
        }
    }

    override fun onLocalServerReady(server: DetectedLocalServer) {
        floatingView?.post {
            updateStatusBadge()
        }
    }

    override fun onLocalServerStopped() {
        floatingView?.post {
            updateStatusBadge()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        processManager.removeListener(this)
        if (floatingView != null && windowManager != null) {
            try {
                windowManager?.removeView(floatingView)
            } catch (e: Exception) {
                // View might not be attached
            }
        }
        _binding = null
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, FloatingBallService::class.java)
            context.startService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingBallService::class.java)
            context.stopService(intent)
        }
    }
}
