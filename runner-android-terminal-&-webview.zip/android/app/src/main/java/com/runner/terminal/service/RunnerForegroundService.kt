package com.runner.terminal.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.runner.terminal.MainActivity
import com.runner.terminal.R
import com.runner.terminal.network.DetectedLocalServer
import com.runner.terminal.process.ProcessState
import com.runner.terminal.process.RunnerProcessManager

class RunnerForegroundService : Service(), RunnerProcessManager.ProcessEventListener {

    private val processManager = RunnerProcessManager.instance
    private var notificationManager: NotificationManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
        processManager.addListener(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_PROCESS) {
            processManager.terminateActiveProcess()
            stopSelf()
            return START_NOT_STICKY
        }

        val command = intent?.getStringExtra(EXTRA_COMMAND) ?: "Runner Process"
        val notification = buildNotification(command, processManager.activeDetectedServer?.normalizedUrl)
        startForeground(NOTIFICATION_ID, notification)

        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Runner Background Processes",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows notifications when local servers and scripts run in Runner"
                setShowBadge(false)
            }
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(command: String, serverUrl: String?): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (serverUrl != null) {
                putExtra(MainActivity.EXTRA_TARGET_TAB, "webview")
                putExtra(MainActivity.EXTRA_TARGET_URL, serverUrl)
            } else {
                putExtra(MainActivity.EXTRA_TARGET_TAB, "terminal")
            }
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, RunnerForegroundService::class.java).apply {
            action = ACTION_STOP_PROCESS
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val contentText = if (serverUrl != null) {
            "Server online: $serverUrl"
        } else {
            "Running: $command"
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Runner Environment Active")
            .setContentText(contentText)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (serverUrl != null) {
            builder.addAction(android.R.drawable.ic_menu_view, "Open WebView", openPendingIntent)
        }
        builder.addAction(android.R.drawable.ic_delete, "Stop (Ctrl+C)", stopPendingIntent)

        return builder.build()
    }

    override fun onOutputLine(line: String) {}

    override fun onStateChanged(state: ProcessState) {
        if (state is ProcessState.Completed) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onLocalServerReady(server: DetectedLocalServer) {
        val notification = buildNotification("Local Server", server.normalizedUrl)
        notificationManager?.notify(NOTIFICATION_ID, notification)
    }

    override fun onLocalServerStopped() {
        if (!processManager.isRunning()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        processManager.removeListener(this)
    }

    companion object {
        const val CHANNEL_ID = "runner_channel_process"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_PROCESS = "com.runner.terminal.ACTION_STOP_PROCESS"
        const val EXTRA_COMMAND = "extra_command"

        fun start(context: Context, command: String) {
            val intent = Intent(context, RunnerForegroundService::class.java).apply {
                putExtra(EXTRA_COMMAND, command)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, RunnerForegroundService::class.java)
            context.stopService(intent)
        }
    }
}
