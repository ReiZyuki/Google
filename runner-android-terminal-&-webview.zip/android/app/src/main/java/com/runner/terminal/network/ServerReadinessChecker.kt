package com.runner.terminal.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class ServerReadinessChecker {

    /**
     * Polls the local server host and port until it successfully accepts a socket connection
     * or the timeout is reached.
     *
     * @param host Local host (e.g. "127.0.0.1")
     * @param port Local port (e.g. 5000)
     * @param timeoutSeconds Max duration to probe
     * @return true if the server is accepting connections, false if timed out
     */
    suspend fun waitForServerReady(
        host: String,
        port: Int,
        timeoutSeconds: Int = 5,
        onAttempt: ((attempt: Int) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val timeoutMillis = timeoutSeconds * 1000L
        var attemptCount = 0

        while (System.currentTimeMillis() - startTime < timeoutMillis) {
            attemptCount++
            onAttempt?.invoke(attemptCount)

            if (isPortOpen(host, port, 400)) {
                return@withContext true
            }

            delay(300)
        }

        // Final check
        return@withContext isPortOpen(host, port, 500)
    }

    private fun isPortOpen(host: String, port: Int, socketTimeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), socketTimeoutMs)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
