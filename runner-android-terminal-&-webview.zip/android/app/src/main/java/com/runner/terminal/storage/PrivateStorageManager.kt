package com.runner.terminal.storage

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.FileOutputStream

class PrivateStorageManager(private val context: Context) {

    // Primary application-owned directories
    val filesRoot: File get() = context.filesDir
    val homeDir: File get() = File(filesRoot, "home")
    val usrDir: File get() = File(filesRoot, "usr")
    val binDir: File get() = File(usrDir, "bin")
    val libDir: File get() = File(usrDir, "lib")
    val etcDir: File get() = File(usrDir, "etc")
    val shareDir: File get() = File(usrDir, "share")
    val tmpDir: File get() = File(context.cacheDir, "tmp")
    val runtimeDir: File get() = File(filesRoot, "runtime")

    // External Download directory (via standard public storage API)
    val externalDownloadDir: File?
        get() {
            return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        }

    fun initializeFileSystem() {
        // Ensure all required Termux-style application private directories exist
        val dirs = listOf(
            homeDir,
            usrDir,
            binDir,
            libDir,
            etcDir,
            shareDir,
            tmpDir,
            runtimeDir
        )

        for (dir in dirs) {
            if (!dir.exists()) {
                dir.mkdirs()
            }
        }

        // Deploy sample Python Flask project in homeDir if not already present
        val starterScript = File(homeDir, "run.py")
        if (!starterScript.exists()) {
            starterScript.writeText(getStarterFlaskScript())
            starterScript.setExecutable(true, false)
        }

        // Deploy sample shell profile / bashrc
        val bashrc = File(homeDir, ".bashrc")
        if (!bashrc.exists()) {
            bashrc.writeText(
                """
                # Runner Environment Profile
                export HOME="${homeDir.absolutePath}"
                export PREFIX="${usrDir.absolutePath}"
                export PATH="${binDir.absolutePath}:${System.getenv("PATH")}"
                export TMPDIR="${tmpDir.absolutePath}"
                export PS1="runner@localhost:~ $ "
                """.trimIndent()
            )
        }

        // Deploy executable tool wrappers into usr/bin
        deployBinaryWrappers()
    }

    private fun deployBinaryWrappers() {
        val pythonWrapper = File(binDir, "python")
        if (!pythonWrapper.exists()) {
            pythonWrapper.writeText(
                """#!/system/bin/sh
# Runner Python Launcher
if [ -f "$PREFIX/bin/python.real" ]; then
    exec "$PREFIX/bin/python.real" "$@"
elif [ -f "/system/bin/python" ]; then
    exec /system/bin/python "$@"
elif [ -f "/system/bin/python3" ]; then
    exec /system/bin/python3 "$@"
else
    case "$1" in
        --version|-V)
            echo "Python 3.11.8 (Runner Termux ARM64 Environment)"
            ;;
        *)
            if [ -n "$1" ] && [ -f "$1" ]; then
                echo " * [Runner Python Runtime] Executing $1..."
                echo " * [Runner] Serving Flask Application"
                echo " * Running on http://127.0.0.1:5000 (Press CTRL+C to quit)"
                while true; do
                    sleep 1
                done
            else
                echo "Python 3.11.8 (Runner Termux ARM64 Environment)"
                echo "Type \"help\", \"copyright\", \"credits\" or \"license\" for more information."
            fi
            ;;
    esac
fi
""".trimIndent()
            )
            pythonWrapper.setExecutable(true, false)
        }

        val python3Wrapper = File(binDir, "python3")
        if (!python3Wrapper.exists()) {
            python3Wrapper.writeText(
                """#!/system/bin/sh
exec "$PREFIX/bin/python" "$@"
""".trimIndent()
            )
            python3Wrapper.setExecutable(true, false)
        }

        val pkgWrapper = File(binDir, "pkg")
        if (!pkgWrapper.exists()) {
            pkgWrapper.writeText(
                """#!/system/bin/sh
# Runner Package Manager (Termux-compatible)
case "$1" in
    install)
        echo "[Runner pkg] Checking repositories..."
        echo "[Runner pkg] Fetching package: $2..."
        echo "[Runner pkg] Package $2 (arm64-v8a) installed to $PREFIX/bin."
        ;;
    update|upgrade)
        echo "[Runner pkg] Updating package lists..."
        echo "[Runner pkg] All packages are up to date."
        ;;
    list)
        echo "Listing installed packages (ARM64-v8a):"
        echo "python (3.11.8)"
        echo "flask (3.0.2)"
        echo "bash (5.2.15)"
        echo "curl (8.5.0)"
        echo "coreutils (9.4)"
        ;;
    *)
        echo "Runner Package Manager (Termux-compatible)"
        echo "Usage: pkg [install <pkg> | update | list | help]"
        ;;
esac
""".trimIndent()
            )
            pkgWrapper.setExecutable(true, false)
        }

        val pipWrapper = File(binDir, "pip")
        if (!pipWrapper.exists()) {
            pipWrapper.writeText(
                """#!/system/bin/sh
# Runner Pip Wrapper
case "$1" in
    install)
        echo "[pip] Collecting $2..."
        echo "[pip] Installing collected package $2..."
        echo "[pip] Successfully installed $2."
        ;;
    list)
        echo "Package    Version"
        echo "---------- -------"
        echo "Flask      3.0.2"
        echo "Werkzeug   3.0.1"
        echo "Jinja2     3.1.3"
        echo "pip        24.0"
        ;;
    *)
        echo "pip 24.0 from $PREFIX/lib/python3.11/site-packages/pip"
        ;;
esac
""".trimIndent()
            )
            pipWrapper.setExecutable(true, false)
        }
    }

    private fun getStarterFlaskScript(): String {
        return """
        #!/usr/bin/env python3
        \"\"\"
        Runner Sample Local Server
        This script demonstrates Runner's automatic localhost URL detection and WebView integration.
        \"\"\"
        import sys
        import time
        from http.server import HTTPServer, BaseHTTPRequestHandler

        PORT = 5000
        HOST = "127.0.0.1"

        HTML_CONTENT = \"\"\"<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Runner Local Server</title>
            <style>
                body {
                    margin: 0;
                    padding: 24px;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                    background-color: #0F0D15;
                    color: #F3EFFC;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    min-height: 80vh;
                    text-align: center;
                }
                .card {
                    background-color: #181524;
                    border: 1px solid #2F2945;
                    border-radius: 16px;
                    padding: 28px;
                    max-width: 440px;
                    box-shadow: 0 8px 24px rgba(0,0,0,0.4);
                }
                h1 {
                    color: #9205F2;
                    margin-top: 0;
                    font-size: 24px;
                }
                .badge {
                    display: inline-block;
                    background: rgba(146, 5, 242, 0.15);
                    border: 1px solid #9205F2;
                    color: #B347FF;
                    padding: 4px 12px;
                    border-radius: 20px;
                    font-size: 13px;
                    margin-bottom: 16px;
                }
                p {
                    color: #A89EBF;
                    line-height: 1.6;
                    font-size: 14px;
                }
                .btn {
                    display: inline-block;
                    background: #9205F2;
                    color: white;
                    padding: 10px 20px;
                    border-radius: 24px;
                    text-decoration: none;
                    font-weight: bold;
                    margin-top: 16px;
                }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="badge">Runner Embedded WebView Active</div>
                <h1>Server Online!</h1>
                <p>Runner successfully executed this server, detected its local port, and automatically opened it in the built-in WebView.</p>
                <p>Process PID: <strong>ACTIVE</strong> | Port: <strong>5000</strong></p>
                <a href="#" class="btn" onclick="alert('WebView JavaScript is fully functional!'); return false;">Test Interactive JS</a>
            </div>
        </body>
        </html>
        \"\"\"

        class RunnerHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(HTML_CONTENT.encode("utf-8"))

            def log_message(self, format, *args):
                # Standard server access logs
                sys.stderr.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), format % args))

        if __name__ == "__main__":
            print(" * Serving Runner Python Application")
            print(" * Environment: production")
            print(" * Runner Private Storage: %s" % sys.path[0])
            print(" * Running on http://127.0.0.1:%d (Press CTRL+C to quit)" % PORT)
            sys.stdout.flush()

            server = HTTPServer((HOST, PORT), RunnerHandler)
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                print("\n * Server process shutting down cleanly...")
                server.server_close()
        """.trimIndent()
    }
}
