package com.runner.terminal.ui.terminal

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.Fragment
import com.runner.terminal.MainActivity
import com.runner.terminal.R
import com.runner.terminal.RunnerApplication
import com.runner.terminal.databinding.FragmentTerminalBinding
import com.runner.terminal.network.DetectedLocalServer
import com.runner.terminal.process.ProcessState
import com.runner.terminal.process.RunnerProcessManager
import java.io.File

class TerminalFragment : Fragment(), RunnerProcessManager.ProcessEventListener {

    private var _binding: FragmentTerminalBinding? = null
    private val binding get() = _binding!!

    private val processManager = RunnerProcessManager.instance
    private var workingDirectory: File = RunnerApplication.instance.storageManager.homeDir

    private val commandHistory = mutableListOf<String>()
    private var historyIndex = -1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTerminalBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Apply custom font size from preferences
        val fontSize = RunnerApplication.instance.preferencesManager.terminalFontSize
        binding.tvTerminalOutput.textSize = fontSize

        // Initial welcome message if terminal is fresh
        if (binding.tvTerminalOutput.text.isEmpty()) {
            val homePath = RunnerApplication.instance.storageManager.homeDir.absolutePath
            val welcome = getString(R.string.terminal_welcome, homePath)
            binding.tvTerminalOutput.text = welcome
            appendPrompt()
        }

        setupInput()
        setupQuickKeys()
        checkActiveServer()

        processManager.addListener(this)
    }

    private fun setupInput() {
        binding.etCommandLine.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE) {
                submitCommand()
                true
            } else {
                false
            }
        }

        binding.btnSendCommand.setOnClickListener {
            submitCommand()
        }
    }

    private fun setupQuickKeys() {
        binding.btnKeyCtrlC.setOnClickListener {
            processManager.terminateActiveProcess()
        }

        binding.btnKeyClear.setOnClickListener {
            binding.tvTerminalOutput.text = ""
            appendPrompt()
        }

        binding.btnKeyLs.setOnClickListener {
            binding.etCommandLine.setText("ls -la")
            submitCommand()
        }

        binding.btnKeyRunFlask.setOnClickListener {
            binding.etCommandLine.setText("python run.py")
            submitCommand()
        }

        binding.btnOpenDetectedInWebView.setOnClickListener {
            val server = processManager.activeDetectedServer
            if (server != null) {
                (activity as? MainActivity)?.openWebView(server.normalizedUrl)
            }
        }
    }

    private fun submitCommand() {
        val rawCommand = binding.etCommandLine.text.toString().trim()
        binding.etCommandLine.setText("")

        if (rawCommand.isEmpty()) {
            appendPrompt()
            return
        }

        commandHistory.add(rawCommand)
        historyIndex = commandHistory.size

        // Display typed command in terminal log
        binding.tvTerminalOutput.append(rawCommand + "\n")
        scrollToBottom()

        // Handle internal shell navigation (e.g. cd)
        if (rawCommand.startsWith("cd ") || rawCommand == "cd") {
            handleCdCommand(rawCommand)
            return
        }

        if (rawCommand == "clear") {
            binding.tvTerminalOutput.text = ""
            appendPrompt()
            return
        }

        if (rawCommand == "help") {
            displayHelp()
            appendPrompt()
            return
        }

        // Execute command in the real Linux shell environment
        processManager.executeCommand(rawCommand, workingDirectory)
    }

    private fun handleCdCommand(cmd: String) {
        val storage = RunnerApplication.instance.storageManager
        val targetPath = if (cmd == "cd") {
            storage.homeDir.absolutePath
        } else {
            cmd.substring(3).trim()
        }

        val newDir = if (targetPath.startsWith("/")) {
            File(targetPath)
        } else if (targetPath.startsWith("~")) {
            File(storage.homeDir, targetPath.removePrefix("~").removePrefix("/"))
        } else {
            File(workingDirectory, targetPath)
        }

        if (newDir.exists() && newDir.isDirectory) {
            workingDirectory = newDir
        } else {
            binding.tvTerminalOutput.append("sh: cd: $targetPath: No such file or directory\n")
        }
        appendPrompt()
        scrollToBottom()
    }

    private fun displayHelp() {
        val helpText = """
        Runner Shell & Runtime Helper:
          • ls, pwd, cat, mkdir, rm - Standard Linux file utilities
          • cd <dir> - Change current working directory
          • python run.py - Launch starter local server with Flask auto-detection
          • env - Inspect private environment variables (HOME, PREFIX, PATH)
          • clear - Clear terminal output
          • Ctrl+C - Terminate active running background process
        """.trimIndent()
        binding.tvTerminalOutput.append(helpText + "\n")
    }

    private fun appendPrompt() {
        val homePath = RunnerApplication.instance.storageManager.homeDir.absolutePath
        val currentDisplay = if (workingDirectory.absolutePath == homePath) "~" else workingDirectory.name
        binding.tvTerminalOutput.append("runner@localhost:$currentDisplay $ ")
        binding.tvPromptLabel.text = "$ "
    }

    private fun scrollToBottom() {
        binding.terminalScrollView.post {
            binding.terminalScrollView.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun checkActiveServer() {
        val server = processManager.activeDetectedServer
        if (server != null && processManager.isRunning()) {
            binding.layoutDetectedServerBanner.visibility = View.VISIBLE
            binding.tvDetectedServerMessage.text = "Server active: ${server.normalizedUrl}"
        } else {
            binding.layoutDetectedServerBanner.visibility = View.GONE
        }
    }

    override fun onOutputLine(line: String) {
        if (_binding == null) return
        binding.tvTerminalOutput.append(line)
        scrollToBottom()
    }

    override fun onStateChanged(state: ProcessState) {
        if (_binding == null) return
        if (state is ProcessState.Completed) {
            appendPrompt()
            scrollToBottom()
        }
    }

    override fun onLocalServerReady(server: DetectedLocalServer) {
        if (_binding == null) return
        binding.layoutDetectedServerBanner.visibility = View.VISIBLE
        binding.tvDetectedServerMessage.text = "Server ready: ${server.normalizedUrl}"
    }

    override fun onLocalServerStopped() {
        if (_binding == null) return
        binding.layoutDetectedServerBanner.visibility = View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        processManager.removeListener(this)
        _binding = null
    }
}
