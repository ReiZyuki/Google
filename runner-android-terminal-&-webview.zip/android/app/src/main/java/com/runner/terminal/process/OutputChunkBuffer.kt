package com.runner.terminal.process

/**
 * Maintains a sliding buffer of recent output chunks to detect tokens and URLs
 * that span across read boundaries (e.g. chunk 1: "http://127.0.", chunk 2: "0.1:5000").
 */
class OutputChunkBuffer(private val maxBufferSize: Int = 4096) {

    private val buffer = StringBuilder()

    @Synchronized
    fun append(chunk: String): String {
        buffer.append(chunk)
        if (buffer.length > maxBufferSize) {
            buffer.delete(0, buffer.length - maxBufferSize)
        }
        return buffer.toString()
    }

    @Synchronized
    fun clear() {
        buffer.setLength(0)
    }

    @Synchronized
    fun getBufferedText(): String {
        return buffer.toString()
    }
}
