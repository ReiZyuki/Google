package com.runner.terminal.data

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    var themeMode: String
        get() = prefs.getString(KEY_THEME_MODE, THEME_DARK) ?: THEME_DARK
        set(value) = prefs.edit().putString(KEY_THEME_MODE, value).apply()

    var autoOpenWebView: Boolean
        get() = prefs.getBoolean(KEY_AUTO_OPEN_WEBVIEW, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_OPEN_WEBVIEW, value).apply()

    var serverTimeoutSeconds: Int
        get() = prefs.getInt(KEY_SERVER_TIMEOUT, 5)
        set(value) = prefs.edit().putInt(KEY_SERVER_TIMEOUT, value).apply()

    var terminalFontSize: Float
        get() = prefs.getFloat(KEY_TERMINAL_FONT_SIZE, 13f)
        set(value) = prefs.edit().putFloat(KEY_TERMINAL_FONT_SIZE, value).apply()

    var floatingBallEnabled: Boolean
        get() = prefs.getBoolean(KEY_FLOATING_BALL_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_FLOATING_BALL_ENABLED, value).apply()

    companion object {
        private const val PREF_NAME = "runner_preferences"
        const val KEY_THEME_MODE = "key_theme_mode"
        const val KEY_AUTO_OPEN_WEBVIEW = "key_auto_open_webview"
        const val KEY_SERVER_TIMEOUT = "key_server_timeout"
        const val KEY_TERMINAL_FONT_SIZE = "key_terminal_font_size"
        const val KEY_FLOATING_BALL_ENABLED = "key_floating_ball_enabled"

        const val THEME_DARK = "dark"
        const val THEME_LIGHT = "light"
        const val THEME_SYSTEM = "system"
    }
}
