package com.runner.terminal.process

import android.os.Handler
import android.os.Looper
import com.runner.terminal.RunnerApplication
import com.runner.terminal.network.DetectedLocalServer
import com.runner.terminal.network.LocalUrlDetector
import com.runner.terminal.network.ServerReadinessChecker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStream

sealed class ProcessState {
    object Idle : ProcessState()
    data class Running(val command: String, val pid: Long) : ProcessState()
    data class Completed(val exitCode: Int) : ProcessState()
}

class RunnerProcessManager {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var activeProcess: Process? = null
    private var processJob: Job? = null
    private var processOutputStream: OutputStream? = null

    private val urlDetector = LocalUrlDetector()
    private val readinessChecker = ServerReadinessChecker()
    private val chunkBuffer = OutputChunkBuffer()

    var activeDetectedServer: DetectedLocalServer? = null
        private set

    private val listeners = mutableListOf<ProcessEventListener>()

    interface ProcessEventListener {
        fun onOutputLine(line: String)
        fun onStateChanged(state: ProcessState)
        fun onLocalServerReady(server: DetectedLocalServer)
        fun onLocalServerStopped()
    }

    fun addListener(listener: ProcessEventListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeListener(listener: ProcessEventListener) {
        listeners.remove(listener)
    }

    fun isRunning(): Boolean {
        return activeProcess != null
    }

    /**
     * Executes a command inside the Runner Linux environment.
     */
    fun executeCommand(command: String, workingDirectory: File = RunnerApplication.instance.storageManager.homeDir) {
        if (activeProcess != null) {
            notifyOutput("\n[Runner] Another process is already running. Press Ctrl+C to terminate it first.\n")
            return
        }

        chunkBuffer.clear()
        activeDetectedServer = null

        processJob = coroutineScope.launch {
            try {
                val storage = RunnerApplication.instance.storageManager
                val prefs = RunnerApplication.instance.preferencesManager

                // Build execution environment
                val processBuilder = ProcessBuilder()
                processBuilder.directory(workingDirectory)

                // Android provides real /system/bin/sh on all devices
                val shellBinary = if (File("/system/bin/sh").exists()) "/system/bin/sh" else "sh"
                processBuilder.command(shellBinary, "-c", command)

                // Termux-style application private environment variables
                val env = processBuilder.environment()
                env["HOME"] = storage.homeDir.absolutePath
                env["PREFIX"] = storage.usrDir.absolutePath
                env["PATH"] = "${storage.binDir.absolutePath}:/system/bin:/system/xbin:${System.getenv("PATH") ?: ""}"
                env["TMPDIR"] = storage.tmpDir.absolutePath
                env["PYTHONUNBUFFERED"] = "1"
                env["TERM"] = "xterm-256color"

                processBuilder.redirectErrorStream(true)

                val process = processBuilder.start()
                activeProcess = process
                processOutputStream = process.outputStream

                val pid = try {
                    // Java 9+ Process.pid() is available on Android API 28+
                    process.javaClass.getMethod("pid").invoke(process) as? Long ?: 1001L
                } catch (e: Exception) {
                    1001L
                }

                mainHandler.post {
                    for (l in listeners) l.onStateChanged(ProcessState.Running(command, pid))
                }

                val reader = BufferedReader(InputStreamReader(process.inputStream))
                val buffer = CharArray(1024)
                var charsRead: Int

                while (reader.read(buffer).also { charsRead = it } != -1) {
                    val chunk = String(buffer, 0, charsRead)
                    notifyOutput(chunk)

                    // Pass chunk to sliding window buffer for robust multi-chunk URL detection
                    val bufferedText = chunkBuffer.append(chunk)

                    if (activeDetectedServer == null) {
                        val detected = urlDetector.findLocalServerUrl(bufferedText)
                        if (detected != null) {
                            activeDetectedServer = detected
                            notifyOutput("\n[Runner Detector] Found localhost URL: ${detected.normalizedUrl}\n[Runner] Verifying server readiness...\n")

                            // Probe server readiness in background before opening WebView
                            coroutineScope.launch {
                                val isReady = readinessChecker.waitForServerReady(
                                    host = detected.host,
                                    port = detected.port,
                                    timeoutSeconds = prefs.serverTimeoutSeconds
                                )

                                if (isReady) {
                                    mainHandler.post {
                                        notifyOutput("[Runner] Server is reachable! Opening built-in WebView.\n")
                                        if (prefs.autoOpenWebView) {
                                            for (l in listeners) l.onLocalServerReady(detected)
                                        }
                                    }
                                } else {
                                    notifyOutput("[Runner Warning] Server did not respond within ${prefs.serverTimeoutSeconds}s.\n")
                                }
                            }
                        }
                    }
                }

                val exitCode = process.waitFor()
                activeProcess = null
                processOutputStream = null

                mainHandler.post {
                    notifyOutput("\n[Process exited with status $exitCode]\n")
                    for (l in listeners) {
                        l.onStateChanged(ProcessState.Completed(exitCode))
                        l.onLocalServerStopped()
                    }
                }

            } catch (e: Exception) {
                activeProcess = null
                processOutputStream = null
                mainHandler.post {
                    notifyOutput("\n[Execution Error: ${e.localizedMessage}]\n")
                    for (l in listeners) {
                        l.onStateChanged(ProcessState.Completed(-1))
                        l.onLocalServerStopped()
                    }
                }
            }
        }
    }

    /**
     * Sends input into the running process's stdin.
     */
    fun sendInput(input: String) {
        try {
            processOutputStream?.let { os ->
                os.write(input.toByteArray(Charsets.UTF_8))
                os.flush()
            }
        } catch (e: Exception) {
            // Process might have terminated
        }
    }

    /**
     * Terminates the active process (equivalent to Ctrl+C / SIGINT).
     */
    fun terminateActiveProcess() {
        try {
            activeProcess?.destroy()
            activeProcess = null
            processJob?.cancel()
            notifyOutput("\n^C\n[Runner] Process terminated.\n")
            mainHandler.post {
                for (l in listeners) {
                    l.onStateChanged(ProcessState.Completed(130))
                    l.onLocalServerStopped()
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun notifyOutput(text: String) {
        mainHandler.post {
            for (l in listeners) {
                l.onOutputLine(text)
            }
        }
    }

    companion object {
        val instance: RunnerProcessManager by lazy { RunnerProcessManager() }
    }
}
