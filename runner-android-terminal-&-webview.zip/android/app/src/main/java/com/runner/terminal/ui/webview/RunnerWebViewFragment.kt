package com.runner.terminal.ui.webview

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import com.runner.terminal.MainActivity
import com.runner.terminal.databinding.FragmentWebviewBinding
import com.runner.terminal.process.RunnerProcessManager

class RunnerWebViewFragment : Fragment() {

    private var _binding: FragmentWebviewBinding? = null
    private val binding get() = _binding!!

    private var targetUrl: String = "http://127.0.0.1:5000"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.getString(ARG_URL)?.let {
            targetUrl = it
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWebviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvCurrentWebUrl.text = targetUrl

        configureWebView()
        setupNavigationControls()

        loadTargetUrl(targetUrl)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val webView = binding.internalWebView
        val settings = webView.settings

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.cacheMode = WebSettings.LOAD_NO_CACHE
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (_binding == null) return
                if (newProgress < 100) {
                    binding.webProgressBar.visibility = View.VISIBLE
                    binding.webProgressBar.progress = newProgress
                } else {
                    binding.webProgressBar.visibility = View.GONE
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (_binding == null) return
                binding.layoutServerError.visibility = View.GONE
                binding.internalWebView.visibility = View.VISIBLE
                if (url != null) binding.tvCurrentWebUrl.text = url
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (_binding == null) return
                if (url != null) binding.tvCurrentWebUrl.text = url
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    showServerError()
                }
            }
        }
    }

    private fun setupNavigationControls() {
        binding.btnWebBack.setOnClickListener {
            if (binding.internalWebView.canGoBack()) {
                binding.internalWebView.goBack()
            }
        }

        binding.btnWebForward.setOnClickListener {
            if (binding.internalWebView.canGoForward()) {
                binding.internalWebView.goForward()
            }
        }

        binding.btnWebReload.setOnClickListener {
            binding.internalWebView.reload()
        }

        binding.btnWebReturnTerminal.setOnClickListener {
            (activity as? MainActivity)?.navigateToTerminal()
        }

        binding.btnWebClose.setOnClickListener {
            (activity as? MainActivity)?.navigateToTerminal()
        }

        binding.btnRetryServerConnection.setOnClickListener {
            loadTargetUrl(targetUrl)
        }

        binding.btnErrorBackToTerminal.setOnClickListener {
            (activity as? MainActivity)?.navigateToTerminal()
        }
    }

    fun loadTargetUrl(url: String) {
        targetUrl = url
        if (_binding != null) {
            binding.tvCurrentWebUrl.text = url
            binding.layoutServerError.visibility = View.GONE
            binding.internalWebView.visibility = View.VISIBLE
            binding.internalWebView.loadUrl(url)
        }
    }

    private fun showServerError() {
        if (_binding == null) return
        binding.internalWebView.visibility = View.GONE
        binding.layoutServerError.visibility = View.VISIBLE
        binding.tvServerErrorMessage.text =
            "The local server at $targetUrl is not responding.\nVerify the server process in the Terminal."
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding.internalWebView.stopLoading()
        _binding = null
    }

    companion object {
        private const val ARG_URL = "arg_url"

        fun newInstance(url: String): RunnerWebViewFragment {
            val fragment = RunnerWebViewFragment()
            val args = Bundle()
            args.putString(ARG_URL, url)
            fragment.arguments = args
            return fragment
        }
    }
}
