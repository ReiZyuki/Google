package com.runner.terminal

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.runner.terminal.data.PreferencesManager
import com.runner.terminal.storage.PrivateStorageManager

class RunnerApplication : Application() {

    lateinit var storageManager: PrivateStorageManager
        private set

    lateinit var preferencesManager: PreferencesManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        preferencesManager = PreferencesManager(this)
        storageManager = PrivateStorageManager(this)
        storageManager.initializeFileSystem()

        // Apply user-configured theme
        applyAppTheme(preferencesManager.themeMode)
    }

    fun applyAppTheme(themeMode: String) {
        when (themeMode) {
            PreferencesManager.THEME_LIGHT -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            PreferencesManager.THEME_DARK -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    companion object {
        lateinit var instance: RunnerApplication
            private set
    }
}
