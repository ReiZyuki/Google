package com.runner.terminal.ui.files

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.runner.terminal.R
import com.runner.terminal.RunnerApplication
import com.runner.terminal.databinding.DialogTextEditorBinding
import com.runner.terminal.databinding.FragmentFileManagerBinding
import com.runner.terminal.storage.FileItem
import com.runner.terminal.storage.FileManagerHelper
import java.io.File

class FileManagerFragment : Fragment() {

    private var _binding: FragmentFileManagerBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: FileAdapter
    private var currentDirectory: File = RunnerApplication.instance.storageManager.homeDir
    private var isCurrentPrivate: Boolean = true

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFileManagerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupChips()
        setupActionButtons()

        navigateTo(RunnerApplication.instance.storageManager.homeDir, isPrivate = true)
    }

    private fun setupRecyclerView() {
        adapter = FileAdapter(
            onItemClick = { item ->
                if (item.isDirectory) {
                    navigateTo(item.file, item.isPrivateStorage)
                } else {
                    openTextEditor(item.file)
                }
            },
            onOptionsClick = { item, popup ->
                popup.setOnMenuItemClickListener { menuItem ->
                    when (menuItem.title) {
                        "⚡ Quickly Run" -> executeQuickRun(item.file)
                        "Open / Edit" -> openTextEditor(item.file)
                        "Rename" -> showRenameDialog(item.file)
                        "Delete" -> showDeleteConfirmDialog(item.file)
                        "Details" -> showDetailsDialog(item)
                    }
                    true
                }
            },
            onQuickRunClick = { item ->
                executeQuickRun(item.file)
            }
        )
        binding.recyclerViewFiles.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewFiles.adapter = adapter
    }

    private fun setupChips() {
        val storage = RunnerApplication.instance.storageManager

        binding.chipHome.setOnClickListener {
            navigateTo(storage.homeDir, isPrivate = true)
        }
        binding.chipRuntime.setOnClickListener {
            navigateTo(storage.usrDir, isPrivate = true)
        }
        binding.chipFiles.setOnClickListener {
            navigateTo(storage.filesRoot, isPrivate = true)
        }
        binding.chipDownload.setOnClickListener {
            val downloadDir = storage.externalDownloadDir
            if (downloadDir != null && downloadDir.exists()) {
                navigateTo(downloadDir, isPrivate = false)
            } else {
                Toast.makeText(requireContext(), "External Download directory not accessible", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupActionButtons() {
        binding.btnNavigateUp.setOnClickListener {
            val parent = currentDirectory.parentFile
            if (parent != null && parent.canRead()) {
                navigateTo(parent, isCurrentPrivate)
            } else {
                Toast.makeText(requireContext(), "Root reached", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnRefreshFiles.setOnClickListener {
            refreshList()
        }

        binding.btnCreateFile.setOnClickListener {
            showCreateFileDialog()
        }

        binding.btnCreateFolder.setOnClickListener {
            showCreateFolderDialog()
        }

        binding.btnQuickRunRunPy.setOnClickListener {
            // Check for run.py, main.py, or app.py in current directory
            val candidate = listOf("run.py", "main.py", "app.py", "index.html")
                .map { File(currentDirectory, it) }
                .firstOrNull { it.exists() }

            if (candidate != null) {
                executeQuickRun(candidate)
            } else {
                val homeRunPy = File(RunnerApplication.instance.storageManager.homeDir, "run.py")
                if (homeRunPy.exists()) {
                    executeQuickRun(homeRunPy)
                } else {
                    Toast.makeText(requireContext(), "No runnable script (run.py/main.py) found", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun executeQuickRun(file: File) {
        val fileName = file.name
        val parentDir = file.parentFile ?: currentDirectory

        if (fileName.endsWith(".html")) {
            (activity as? MainActivity)?.openWebView("file://${file.absolutePath}")
            Toast.makeText(requireContext(), "⚡ Opened $fileName in WebView", Toast.LENGTH_SHORT).show()
            return
        }

        val command = when {
            fileName.endsWith(".py") -> "cd \"${parentDir.absolutePath}\" && python \"$fileName\""
            fileName.endsWith(".sh") -> "cd \"${parentDir.absolutePath}\" && sh \"$fileName\""
            fileName.endsWith(".js") -> "cd \"${parentDir.absolutePath}\" && node \"$fileName\""
            else -> "cd \"${parentDir.absolutePath}\" && ./\"$fileName\""
        }

        RunnerProcessManager.instance.executeCommand(command)
        Toast.makeText(requireContext(), "⚡ Quickly Running $fileName", Toast.LENGTH_SHORT).show()
        (activity as? MainActivity)?.navigateToTerminal()
    }

    private fun navigateTo(dir: File, isPrivate: Boolean) {
        currentDirectory = dir
        isCurrentPrivate = isPrivate

        binding.tvCurrentPath.text = dir.absolutePath
        if (isPrivate) {
            binding.tvStorageTypeBadge.text = "Runner Private"
            binding.tvStorageTypeBadge.setTextColor(requireContext().getColor(R.color.runner_purple_light))
            binding.tvStorageTypeBadge.setBackgroundResource(R.drawable.bg_badge_private)
        } else {
            binding.tvStorageTypeBadge.text = "Download / External"
            binding.tvStorageTypeBadge.setTextColor(requireContext().getColor(R.color.terminal_cyan))
            binding.tvStorageTypeBadge.setBackgroundResource(R.drawable.bg_badge_server)
        }

        refreshList()
    }

    private fun refreshList() {
        val items = FileManagerHelper.listFiles(currentDirectory, isCurrentPrivate)
        adapter.submitList(items)
    }

    private fun showCreateFileDialog() {
        val input = EditText(requireContext())
        input.hint = "example.py"
        AlertDialog.Builder(requireContext())
            .setTitle("Create New File")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val created = FileManagerHelper.createFile(currentDirectory, name)
                    if (created) {
                        refreshList()
                    } else {
                        Toast.makeText(requireContext(), "Failed to create file", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCreateFolderDialog() {
        val input = EditText(requireContext())
        input.hint = "new_directory"
        AlertDialog.Builder(requireContext())
            .setTitle("Create New Folder")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val created = FileManagerHelper.createDirectory(currentDirectory, name)
                    if (created) {
                        refreshList()
                    } else {
                        Toast.makeText(requireContext(), "Failed to create directory", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRenameDialog(file: File) {
        val input = EditText(requireContext())
        input.setText(file.name)
        AlertDialog.Builder(requireContext())
            .setTitle("Rename")
            .setView(input)
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    if (FileManagerHelper.rename(file, newName)) {
                        refreshList()
                    } else {
                        Toast.makeText(requireContext(), "Failed to rename", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteConfirmDialog(file: File) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete ${file.name}?")
            .setMessage("Are you sure you want to permanently delete this item?")
            .setPositiveButton("Delete") { _, _ ->
                if (FileManagerHelper.delete(file)) {
                    refreshList()
                } else {
                    Toast.makeText(requireContext(), "Failed to delete item", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDetailsDialog(item: FileItem) {
        AlertDialog.Builder(requireContext())
            .setTitle("File Information")
            .setMessage(
                """
                Name: ${item.name}
                Path: ${item.file.absolutePath}
                Size: ${item.formattedSize}
                Modified: ${item.formattedDate}
                Location: ${if (item.isPrivateStorage) "Runner Private Storage" else "External Storage"}
                """.trimIndent()
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun openTextEditor(file: File) {
        val dialogBinding = DialogTextEditorBinding.inflate(layoutInflater)
        dialogBinding.tvEditorTitle.text = file.name

        try {
            dialogBinding.etFileContent.setText(FileManagerHelper.readText(file))
        } catch (e: Exception) {
            dialogBinding.etFileContent.setText("[Binary or unreadable content]")
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .create()

        dialogBinding.btnCancelEditor.setOnClickListener { dialog.dismiss() }
        dialogBinding.btnSaveEditor.setOnClickListener {
            val updated = dialogBinding.etFileContent.text.toString()
            if (FileManagerHelper.writeText(file, updated)) {
                Toast.makeText(requireContext(), "File saved successfully", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                refreshList()
            } else {
                Toast.makeText(requireContext(), "Failed to write to file", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
