package com.runner.terminal.storage

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FileItem(
    val file: File,
    val name: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val isPrivateStorage: Boolean
) {
    val formattedSize: String
        get() {
            if (isDirectory) return "Folder"
            val kb = sizeBytes / 1024.0
            if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb)
            val mb = kb / 1024.0
            return String.format(Locale.US, "%.1f MB", mb)
        }

    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.US)
            return sdf.format(Date(lastModified))
        }
}

object FileManagerHelper {

    fun listFiles(directory: File, isPrivateStorage: Boolean): List<FileItem> {
        val files = directory.listFiles() ?: return emptyList()
        return files.map { file ->
            FileItem(
                file = file,
                name = file.name,
                isDirectory = file.isDirectory,
                sizeBytes = if (file.isDirectory) 0L else file.length(),
                lastModified = file.lastModified(),
                isPrivateStorage = isPrivateStorage
            )
        }.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))
    }

    fun createFile(parentDir: File, fileName: String, initialContent: String = ""): Boolean {
        val target = File(parentDir, fileName)
        if (target.exists()) return false
        return try {
            target.writeText(initialContent)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun createDirectory(parentDir: File, dirName: String): Boolean {
        val target = File(parentDir, dirName)
        return target.mkdirs()
    }

    fun rename(source: File, newName: String): Boolean {
        val destination = File(source.parentFile, newName)
        return source.renameTo(destination)
    }

    fun delete(file: File): Boolean {
        return if (file.isDirectory) {
            file.deleteRecursively()
        } else {
            file.delete()
        }
    }

    fun readText(file: File): String {
        return file.readText(Charsets.UTF_8)
    }

    fun writeText(file: File, content: String): Boolean {
        return try {
            file.writeText(content, Charsets.UTF_8)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun copy(source: File, targetDir: File): Boolean {
        return try {
            val dest = File(targetDir, source.name)
            if (source.isDirectory) {
                source.copyRecursively(dest, overwrite = true)
            } else {
                source.copyTo(dest, overwrite = true)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun move(source: File, targetDir: File): Boolean {
        val dest = File(targetDir, source.name)
        return source.renameTo(dest)
    }
}
